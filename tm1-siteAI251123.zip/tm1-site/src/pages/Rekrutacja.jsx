import React from "react";
import { Link } from "react-router-dom";

export default function Rekrutacja() {
  return (
    <div className="container py-5">
      <h1 className="mb-4 text-primary">Rekrutacja 2025/2026</h1>

      <section className="mb-5">
        <h2 className="h4 mb-3">Harmonogram</h2>
        <ul className="list-group mb-3">
          <li className="list-group-item">Od 1 marca – rozpoczęcie składania wniosków</li>
          <li className="list-group-item">Do 30 kwietnia – składanie dokumentów w sekretariacie</li>
          <li className="list-group-item">Maj – rozmowy kwalifikacyjne / testy kierunkowe</li>
          <li className="list-group-item">Czerwiec – ogłoszenie wyników rekrutacji</li>
          <li className="list-group-item">Lipiec – potwierdzenie przyjęcia przez ucznia</li>
        </ul>
        <p>W razie pytań prosimy o kontakt: tel. 22 646 44 99 lub mail <a href="mailto:rekrutacja@tm1.edu.pl">rekrutacja@tm1.edu.pl</a>.</p>
      </section>

      <section className="mb-5">
        <h2 className="h4 mb-3">Wymagane dokumenty</h2>
        <ul className="mb-3">
          <li>Wypełniony wniosek o przyjęcie (formularz w sekcji „Dokumenty do pobrania”).</li>
          <li>Świadectwo ukończenia szkoły podstawowej.</li>
          <li>Zaświadczenie o wynikach egzaminu ósmoklasisty.</li>
          <li>Fotografia legitymacyjna.</li>
        </ul>
        <p>Dokumenty można złożyć osobiście w sekretariacie szkoły lub wysłać w formie elektronicznej na adres: <a href="mailto:rekrutacja@tm1.edu.pl">rekrutacja@tm1.edu.pl</a>.</p>
      </section>

      <section className="mb-5">
        <h2 className="h4 mb-3">Wyniki egzaminów uczniów</h2>
        <p>Nasza szkoła posiada doskonałe wyniki — więcej szczegółów znajdziesz tutaj:</p>
        <p>
          <a href="https://www.otouczelnie.pl/wyniki/matura/technika/mazowieckie/Warszawa/2025" 
             target="_blank" rel="noopener noreferrer"
             className="text-primary">
            Sprawdź wyniki matur 2025 dla Technikum Mechatronicznego nr 1 →
          </a>
        </p>
        <div className="card mt-3">
          <div className="card-body">
            <h5 className="card-title">Najważniejsze statystyki</h5>
            <ul>
              <li>100% zdawalności matury w roku 2023/24 dla naszej szkoły. (<a href="https://dostanesie.pl/8klasa/Warszawa/szkola/138-1-technikum-mechatroniczne" target="_blank" rel="noopener noreferrer">dostanesie.pl</a>)</li>
              <li>Ranking: szkoła zdobyła 1. miejsce w rankingu techników w Warszawie. (<a href="https://mokotow.um.warszawa.pl/-/mokotowskie-technikum-najlepsze-w-polsce" target="_blank" rel="noopener noreferrer">mokotow.um.warszawa.pl</a>)</li>
            </ul>
          </div>
        </div>
      </section>

      <section>
        <h2 className="h4 mb-3">FAQ – najczęstsze pytania</h2>
        <dl>
          <dt><strong>Jak długo trwa nauka?</strong></dt>
          <dd>Nauka w technikum trwa 5 lat (w tym rok podstawowy + cztery lata specjalizacji).</dd>
          <dt><strong>Czy są dostępne klasy dwujęzyczne?</strong></dt>
          <dd>Tak — oferujemy klasy dwujęzyczne (j. angielski + j. niemiecki) dla kierunku Technik Mechatronik. </dd>
          <dt><strong>Czy mogę odbyć praktykę w firmie?</strong></dt>
          <dd>Tak — współpracujemy z wieloma firmami z branży mechatronicznej i IT.</dd>
        </dl>
      </section>
    </div>
  );
}
