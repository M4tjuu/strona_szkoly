import React from "react";
import { useForm } from "react-hook-form";

export default function Kontakt() {
  const { register, handleSubmit, formState: { errors, isSubmitSuccessful } } = useForm();

  const onSubmit = (data) => {
    console.log("Form submitted:", data);
    alert("Dziękujemy! Formularz został wysłany.");
  };

  return (
    <div className="bg-white container py-5">
      <h1 className="mb-4">Kontakt</h1>

      {/* BLOK 1 – DWIE KOLUMNY Z DANYMI */}
      <div className="row mb-5">
        <div className="col-md-6 mb-4">
          <h2 className="h5 mb-3">Dane ogólne</h2>
          <p>
            <strong>Technikum Mechatroniczne nr 1 im. Piotra Drzewieckiego</strong><br />
            ul. Wiśniowa 56<br />
            02-520 Warszawa
          </p>

          <p>
            <strong>Telefon:</strong> 22 646-44-99, 22 646-44-98<br />
            <strong>ePUAP:</strong>{" "}
            <a href="https://epuap.gov.pl" target="_blank" rel="noreferrer">
              https://epuap.gov.pl
            </a><br />
            <strong>Adres do e-doręczeń:</strong><br></br> TI - AE:PL-46723-52871-URRSU-33
          </p>

          <p>
            <strong>IOD – Stanisław Rudowski</strong><br />
            e-mail: <a href="mailto:srowski.iod@dbfomokotow.pl">srowski.iod@dbfomokotow.pl</a>
          </p>

          <p>
            <strong>Rekrutacja:</strong><br />
            e-mail: <a href="mailto:rekrutacja@tm1.edu.pl">rekrutacja@tm1.edu.pl</a>
          </p>

          <p>
            <strong>Archiwum</strong><br />
            e-mail: <a href="mailto:archiwum@tm1.edu.pl">archiwum@tm1.edu.pl</a>
          </p>
        </div>

        <div className="col-md-6 mb-4">
          <h2 className="h5 mb-3">Sekretariaty i kadry</h2><br></br>

          <p>
            <strong>Sekretariat dyrektora, pok. 105</strong><br />
            tel. wew. 113<br />
            e-mail: <a href="mailto:szkola@tm1.edu.pl">szkola@tm1.edu.pl</a>
          </p>

          <p>
            <strong>Sekretariat uczniowski, pok. 104</strong><br />
            tel. wew. 111<br />
            e-mail: <a href="mailto:sekretariat@tm1.edu.pl">sekretariat@tm1.edu.pl</a>
          </p>

          <p>
            <strong>Dział kadr, pok. 101</strong><br />
            tel. wew. 119<br />
            e-mail: <a href="mailto:joanna.w@tm1.edu.pl">joanna.w@tm1.edu.pl</a><br />
            e-mail: <a href="mailto:justyna.k@tm1.edu.pl">justyna.k@tm1.edu.pl</a>
          </p>

          <p>
            <strong>Kierownik gospodarczy, pok. 102</strong><br />
            tel. wew. 114<br />
            e-mail: <a href="mailto:boguslawa.gronczynska@tm1.edu.pl">boguslawa.gronczynska@tm1.edu.pl</a>
          </p>
        </div>
      </div>

      {/* BLOK 2 — MAPA + FORMULARZ */}
      <div className="row">
        {/* Mapa */}
        <div className="col-lg-6 mb-4">
          <h2 className="h5 mb-3">Mapa</h2>
          <div className="ratio ratio-16x9">
            <iframe
              title="Mapa TM1 Warszawa"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2443.987930603857!2d21.00073531605013!3d52.20443697976333!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x471ecd9f60f1e47f%3A0x7b2e9c3f31ecb028!2sTechnikum%20Mechatroniczne%20nr%201%20w%20Warszawie!5e0!3m2!1spl!2spl!4v1699919489872!5m2!1spl!2spl"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </div>
        </div>

        {/* Formularz */}
        <div className="col-lg-6">
          <h2 className="h5 mb-3">Formularz kontaktowy</h2>

          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="mb-3">
              <label className="form-label">Imię i nazwisko</label>
              <input
                className="form-control"
                {...register("name", { required: true })}
                placeholder="Jan Kowalski"
              />
              {errors.name && <span className="text-danger">To pole jest wymagane</span>}
            </div>

            <div className="mb-3">
              <label className="form-label">Email</label>
              <input
                className="form-control"
                type="email"
                {...register("email", { required: true })}
                placeholder="jan@example.com"
              />
              {errors.email && <span className="text-danger">To pole jest wymagane</span>}
            </div>

            <div className="mb-3">
              <label className="form-label">Wiadomość</label>
              <textarea
                className="form-control"
                rows="5"
                {...register("message", { required: true })}
                placeholder="Twoja wiadomość"
              ></textarea>
              {errors.message && <span className="text-danger">To pole jest wymagane</span>}
            </div>

            <button
              type="submit"
              className="px-3 py-2 bg-[#b3002d] text-white rounded-md hover:bg-[#8a0024] transition"
            >
              Wyślij
            </button>

            {isSubmitSuccessful && (
              <p className="mt-3 text-success">Dziękujemy! Formularz został wysłany.</p>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}
