import React from "react";

export default function Zastepstwa() {
  const zastepstwa = [
    {
      nauczyciel: "Jan Kowalski",
      lekcje: [
        { lekcja: "2", opis: "Klasa 3M – Matematyka", zastepca: "Anna Nowak" },
        { lekcja: "4", opis: "Klasa 1A – Fizyka", zastepca: "Adam Zieliński" },
        { lekcja: "5", opis: "Klasa 2B – Algebra", zastepca: "Katarzyna Milewska" },
      ],
    },
    {
      nauczyciel: "Maria Wiśniewska",
      lekcje: [
        { lekcja: "1", opis: "Klasa 4M – Język polski", zastepca: "Jan Kowalski" },
        { lekcja: "3", opis: "Klasa 2C – Literatura", zastepca: "Anna Nowak" },
      ],
    },
    {
      nauczyciel: "Piotr Nowak",
      lekcje: [
        { lekcja: "2", opis: "Klasa 1M – Informatyka", zastepca: "Tomasz Wójcik" },
        { lekcja: "6", opis: "Klasa 3C – Programowanie", zastepca: "Maciej Zalewski" },
      ],
    },
  ];

  return (
    <div className="bg-white container py-5">
      <h1 className="mb-4 text-[#003366]">Zastępstwa</h1>
      <p className="mb-4">Aktualne zastępstwa za nauczycieli.</p>

      {zastepstwa.map((nauczycielData, index) => (
        <div key={index} className="mb-5">
          <h3 className="mb-3 text-[#003366]">
            Zastępstwa – <strong>{nauczycielData.nauczyciel}</strong>
          </h3>

          <div className="table-responsive">
            <table className="table table-bordered text-center">
              <thead className="table-light">
                <tr>
                  <th>Lekcja</th>
                  <th>Opis</th>
                  <th>Zastępca</th>
                </tr>
              </thead>
              <tbody>
                {nauczycielData.lekcje.map((lekcja, i) => (
                  <tr key={i}>
                    <td className="fw-bold">{lekcja.lekcja}</td>
                    <td>{lekcja.opis}</td>
                    <td>{lekcja.zastepca}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}

      <p className="mt-3 text-muted">
        Dane są przykładowe. Zastępstwa aktualizowane są codziennie rano.
      </p>
    </div>
  );
}
