import React from "react";
import { Link } from "react-router-dom";

function InfoCard({ title, description, link }) {
  return (
    <div className="bg-white shadow-md rounded-md p-6 hover:shadow-lg transition flex flex-col justify-between">
      <h3 className="text-xl font-bold mb-2 text-[#003366]">{title}</h3>
      <p className="text-gray-700 mb-4">{description}</p>
      {link && (
        <Link
          to={link}
          className="px-3 py-2 bg-[#b3002d] text-white rounded-md hover:bg-[#8a0024] transition self-start"
        >
          Zobacz więcej
        </Link>
      )}
    </div>
  );
}

export default function Kandydat() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-extrabold text-[#003366] mb-4">Strefa kandydata</h1>
      <p className="mb-8 text-gray-700">
        Dowiedz się wszystkiego o naszej szkole i kierunkach kształcenia. Znajdziesz tu informacje o rekrutacji i profilach nauczania.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <InfoCard
          title="Kierunki kształcenia"
          description="Poznaj szczegóły poszczególnych kierunków nauczania w naszej szkole."
          link="/dokumenty"
        />
        <InfoCard
          title="Rekrutacja"
          description="Sprawdź terminy rekrutacji i wymagane dokumenty."
          link="/rekrutacja"
        />
        <InfoCard
          title="Poznaj nas"
          description="Dowiedz się kim jesteśmy i jaki jest nasz cel."
          link="/about"
        />
      </div>
    </div>
  );
}
