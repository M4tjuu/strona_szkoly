import React from "react";

export default function About() {
  return (
    <div className="container py-5">
      <h1 className="mb-4 text-primary">O szkole</h1>

      <section className="mb-5">
        <h2 className="h4 mb-3">Historia szkoły</h2>
        <p>
          Technikum Mechatroniczne nr 1 w Warszawie jest jedną z najstarszych i najbardziej renomowanych
          szkół technicznych w stolicy. Od wielu lat kształci specjalistów w dziedzinie mechatroniki,
          elektroniki i automatyki.
        </p>
      </section>

      <section className="mb-5">
        <h2 className="h4 mb-3">Misja i wartości</h2>
        <p>
          Naszą misją jest przygotowanie uczniów do pracy w nowoczesnym przemyśle poprzez praktyczne
          zajęcia laboratoryjne, rozwój umiejętności technicznych oraz wspieranie kreatywności i innowacji.
        </p>
      </section>

      <section>
        <h2 className="h4 mb-3">Galeria zdjęć</h2>
        <div className="row g-3">
          <div className="col-6 col-md-3">
            <img src="/src/assets/school1.jpg" alt="Szkoła 1" className="img-fluid rounded" />
          </div>
          <div className="col-6 col-md-3">
            <img src="/src/assets/school2.jpg" alt="Szkoła 2" className="img-fluid rounded" />
          </div>
          <div className="col-6 col-md-3">
            <img src="/src/assets/school3.jpg" alt="Szkoła 3" className="img-fluid rounded" />
          </div>
          <div className="col-6 col-md-3">
            <img src="/src/assets/school4.jpg" alt="Szkoła 4" className="img-fluid rounded" />
          </div>
        </div>
      </section>
    </div>
  );
}
