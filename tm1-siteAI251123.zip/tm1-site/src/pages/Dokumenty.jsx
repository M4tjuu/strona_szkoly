import React from "react";

export default function Dokumenty() {
  return (
    <div className="container bg-white py-5">
      <h1 className="mb-4 text-[#003366]">Dokumenty</h1>
      <p className="mb-4">Poniżej znajdują się najważniejsze dokumenty szkolne dostępne do pobrania.</p>

      <div className="row">

        {/* LEWA KOLUMNA */}
        <div className="col-12 col-md-6 mb-4">

          {/* STATUT */}
          <h4 className="mt-3 mb-2 text-[#003366]">Statut</h4>
          <ul>
            <li>
              <a
                href="/docs/STATUT_DN_22-02-2016.pdf"
                download
                type="application/pdf"
                className="text-decoration-underline text-primary"
              >
                STATUT_DN_22-02-2016
              </a>
            </li>
          </ul>

          {/* PLANY NAUCZANIA */}
          <h4 className="mt-4 mb-2 text-[#003366]">Plany nauczania</h4>
          <ul>
            {[
              ["informatyk", "plan_informatyk.pdf"],
              ["informatyk dwujęzyczny", "plan_informatyk_dwujezyczny.pdf"],
              ["programista", "plan_programista.pdf"],
              ["mechatronik", "plan_mechatronik.pdf"],
            ].map(([label, file]) => (
              <li key={file}>
                <a
                  href={`/docs/${file}`}
                  download
                  type="application/pdf"
                  className="text-decoration-underline text-primary"
                >
                  {label}
                </a>
              </li>
            ))}
          </ul>

          {/* REGULAMINY */}
          <h4 className="mt-4 mb-2 text-[#003366]">Regulaminy i instrukcje BHP</h4>
          <ul>
            <li>
              <a
                href="/docs/regulamin_bhp_tm1.pdf"
                download
                type="application/pdf"
                className="text-decoration-underline text-primary"
              >
                Regulamin bezpieczeństwa i higieny pracy TM1
              </a>
            </li>
          </ul>

          {/* KALENDARZ */}
          <h4 className="mt-4 mb-2 text-[#003366]">Kalendarz roku szkolnego</h4>
          <ul>
            <li>
              <a
                href="/docs/kalendarz2025_2026.pdf"
                download
                type="application/pdf"
                className="text-decoration-underline text-primary"
              >
                kalendarz2025_2026
              </a>
            </li>
          </ul>
        </div>

        {/* PRAWA KOLUMNA */}
        <div className="col-12 col-md-6 mb-4">

          <h4 className="mt-3 mb-2 text-[#003366]">WSO i PSO</h4>
          <p>*WSO jest częścią statutu szkoły</p>

          <ul>
            {[
              ["matematyka", "pso_matematyka.pdf"],
              ["fizyka poziom rozszerzony", "pso_fizyka_rozszerzony.pdf"],
              ["fizyka poziom podstawowy", "pso_fizyka_podstawowy.pdf"],
              ["informatyka", "pso_informatyka.pdf"],
              ["język angielski", "pso_angielski.pdf"],
              ["język polski", "pso_polski.pdf"],
              ["biologia", "pso_biologia.pdf"],
              ["chemia", "pso_chemia.pdf"],
              ["geografia", "pso_geografia.pdf"],
              ["historia", "pso_historia.pdf"],
              ["przedmiotowy system oceniania – języki obce II", "pso_jezyki_obce2.pdf"],
              ["przedmioty zawodowe SOJM", "pso_zawodowe_sojm.pdf"],
              ["system oceniania jednostek modułowych", "system_oceniania_moduly.pdf"],
            ].map(([label, file]) => (
              <li key={file}>
                <a
                  href={`/docs/${file}`}
                  download
                  type="application/pdf"
                  className="text-decoration-underline text-primary"
                >
                  {label}
                </a>
              </li>
            ))}
          </ul>

        </div>
      </div>
    </div>
  );
}
