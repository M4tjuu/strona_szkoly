import { Link } from "react-router-dom";
import logo from "/src/assets/logo_tm1.png";
import inicjatywyImg from "/src/assets/inicjatywa.png";
import firm1 from "/src/assets/cisco.png";
import firm2 from "/src/assets/polaris.png";
import firm3 from "/src/assets/pzu.png";
import firm4 from "/src/assets/toyota.png";
import strefaUczniaImg from "/src/assets/uczencropped.png";
import strefaRodzicaImg from "/src/assets/rodziccropped.png";
import strefaKandydataImg from "/src/assets/kandydatcropped.png";

function NewsCard({ title, image, description, link }) {
  return (
    <div className="bg-white rounded-md shadow-md overflow-hidden flex flex-col md:flex-row">
      <img
        src={image}
        alt={title}
        className="w-full md:w-1/3 h-48 md:h-auto object-cover"
      />
      <div className="p-6 flex flex-col justify-between">
        <h3 className="text-2xl font-bold mb-2 text-[#003366]">{title}</h3>
        <p className="text-gray-700 mb-4">{description}</p>
        {link && (
          <Link
            to={link}
            className="px-3 py-2 bg-[#b3002d] text-white rounded-md hover:bg-[#8a0024] transition self-start"
          >
            Zobacz więcej
          </Link>
        )}
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <div className="w-full font-sans">

      {/* Sektor 1: Logo + nazwa szkoły */}
      <section className="bg-white py-8 flex flex-col md:flex-row items-center justify-center gap-4 px-4">
        <img src={logo} alt="Logo szkoły" className="h-24 md:h-32" />
        <h1 className="text-3xl md:text-5xl font-extrabold uppercase text-[#003366] text-center md:text-left leading-tight">
          Technikum Mechatroniczne nr 1 w Warszawie
        </h1>
      </section>

      {/* Sektor 2: przycisk + hero image */}
      <section className="bg-[#f7f7f7] py-8 px-4 md:px-16 flex flex-col items-center gap-6">
        <div className="w-full md:w-11/12 flex justify-end">
          <Link
            to="/about"
            className="px-3 py-2 bg-[#b3002d] text-white rounded-md hover:bg-[#8a0024] transition"
          >
            O szkole
          </Link>
        </div>

        <img
          src="/src/assets/hero_tm1.jpg"
          alt="Hero TM1"
          className="w-full md:w-11/12 h-144 object-cover object-bottom rounded-md shadow-lg"
        />
      </section>


      {/* Sektor 3: Strefy ucznia, rodzica, kandydata */}
      <section className="py-12 bg-white">
        <div className="flex mx-0 md:mx-[10%] xl:mx-[7.2%] items-center justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <NewsCard
            title="Strefa ucznia"
            image={strefaUczniaImg}
            description="Sprawdź aktualności, zmiany w planie lekcji, najbliższe dni wolne"
            link="/uczen"
          />
          <NewsCard
            title="Strefa rodzica"
            image={strefaRodzicaImg}
            description="Informacje o składkach, zebraniach, wycieczkach"
            link="/rodzic"
          />
          <NewsCard
            title="Strefa kandydata"
            image={strefaKandydataImg}
            description="Dowiedz się więcej o poszczególnych kierunkach"
            link="/kandydat"
          />
        </div>
        </div>
      </section>

      {/* Sektor 4: Inicjatywy uczniowskie */}
      <section className="bg-[#f7f7f7] py-12 px-4 md:px-16 flex flex-col lg:flex-row items-center gap-8">
        <div className="lg:w-1/2 flex justify-center lg:justify-end">
          <img src={inicjatywyImg} alt="Inicjatywy" className="w-full lg:w-10/12 rounded-md shadow-lg" />
        </div>
        <div className="lg:w-1/2 flex flex-col gap-6 text-left">
          <h2 className="text-4xl font-extrabold text-[#003366] mb-6">Inicjatywy uczniowskie</h2>
          <div>
            <h3 className="text-2xl font-semibold mb-1">Wolontariat</h3>
            <p className="text-gray-700">Dołącz do zespołu organizującego m.in. zbiórki pieniędzy na szczytne cele.</p>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-1">Samorząd uczniowski</h3>
            <p className="text-gray-700">Masz pomysły na zmiany? Poznaj inne osoby, które biorą sprawy we własne ręce.</p>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-1">Koła zainteresowań</h3>
            <p className="text-gray-700">Chcesz rozwijać swoje pasje? Dołącz do kół uczniowskich lub załóż własne!</p>
          </div>

          <div>
            <Link
              to="https://wisniowasu.pl/"
              className="px-3 py-2 bg-[#b3002d] text-white rounded-md hover:bg-[#8a0024] transition"
            >
              Dowiedz się więcej
            </Link>
          </div>
        </div>
      </section>

      {/* Sektor 5: Firmy współpracujące */}
      <section className="bg-white py-12 px-4 md:px-16">
        <h2 className="text-3xl font-bold text-left text-[#003366] mb-8">
          Firmy współpracujące
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="flex justify-center">
            <img src={firm1} alt="Cisco" className="h-75 object-contain" />
          </div>
          <div className="flex justify-center">
            <img src={firm2} alt="Polaris" className="h-75 object-contain" />
          </div>
          <div className="flex justify-center">
            <img src={firm3} alt="PZU" className="h-75 object-contain" />
          </div>
          <div className="flex justify-center">
            <img src={firm4} alt="Toyota" className="h-75 object-contain" />
          </div>
        </div>
      </section>


    </div>
  );
}
