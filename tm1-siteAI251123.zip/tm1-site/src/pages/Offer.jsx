import React from "react";

export default function Offer() {
  const offers = [
    {
      title: "Technik Mechatronik",
      description:
        "Kształcenie w zakresie mechatroniki, automatyki i robotyki. Praktyczne zajęcia w laboratoriach.",
      icon: "/src/assets/mechatronik.png",
    },
    {
      title: "Technik Elektronik",
      description:
        "Nauka elektroniki, systemów cyfrowych i programowania urządzeń elektronicznych.",
      icon: "/src/assets/elektronik.png",
    },
    {
      title: "Technik Automatyk",
      description:
        "Programowanie i obsługa systemów automatyki przemysłowej oraz PLC.",
      icon: "/src/assets/automatyk.png",
    },
    {
      title: "Technik Informatyk",
      description:
        "Praktyczne zajęcia z programowania, sieci komputerowych i systemów IT.",
      icon: "/src/assets/informatyk.png",
    },
  ];

  return (
    <div className="container py-5">
      <h1 className="mb-4 text-primary">Oferta edukacyjna</h1>
      <div className="row g-4">
        {offers.map((offer, i) => (
          <div key={i} className="col-12 col-md-6 col-lg-3">
            <div className="card h-100 shadow-sm border-0">
              {/* Obrazek cropowany jak w NewsCard */}
              <div
                className="card-img-top"
                style={{
                  backgroundImage: `url(${offer.icon})`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                  height: "200px",
                }}
              ></div>
              <div className="card-body text-center">
                <h5 className="card-title text-primary">{offer.title}</h5>
                <p className="card-text">{offer.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
