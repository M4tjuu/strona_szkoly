import { Link } from "react-router-dom";

export default function NewsCard({ title, image, date, excerpt, link }) {
  return (
    <div className="bg-white rounded-xl shadow hover:shadow-lg transition overflow-hidden border border-gray-200">
      <img
        src={image}
        alt={title}
        className="h-48 w-full object-cover"
      />
      <div className="p-5">
        <p className="text-sm text-gray-500">{date}</p>
        <h3 className="text-lg font-semibold text-[#003366] mb-2">{title}</h3>
        <p className="text-gray-700 mb-4">{excerpt}</p>
        <Link
          to={link}
          className="bg-[#007bff] hover:bg-[#0056b3] text-white px-4 py-1 rounded-md text-sm inline-block"
        >
          Czytaj więcej
        </Link>
      </div>
    </div>
  );
}
