import heroImg from "/src/assets/hero_tm1.jpg";

export default function HeroSection() {
  return (
    <section className="relative h-[500px] w-full">
      <img
        src={heroImg}
        alt="Hero TM1"
        className="absolute w-full h-full object-cover opacity-80"
      />
      <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-white px-4">
        <h1 className="text-4xl md:text-6xl tw-font-bold tw-mb-4">
          Technikum Mechatroniczne nr 1 w Warszawie
        </h1>
        <p className="text-lg md:text-2xl tw-mb-6">
          Kształcimy przyszłych inżynierów i specjalistów mechatroniki
        </p>
      </div>
    </section>
  );
}
