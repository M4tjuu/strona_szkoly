const express = require("express");
const cors = require("cors");
require("dotenv").config();
require("./database");

const nauczycielController = require("./controllers/nauczycielController");
const planRoutes = require("./routes/planRoutes");
const zastepstwaController = require("./controllers/zastepstwaController");

const app = express();
app.use(cors());
app.use(express.json());

// nauczyciele
app.use("/api", nauczycielController);

// plan
app.use("/api/plan", planRoutes);

// zastepstwa
app.use("/api", zastepstwaController);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is listening on ${PORT}`);
});
