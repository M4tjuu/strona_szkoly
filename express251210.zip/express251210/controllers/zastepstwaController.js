const express = require("express");
const router = express.Router();
const Zastepstwa = require("../models/Zastepstwa");

router.get("/zastepstwa", async (req, res) => {
  try {
    const zastepstwa = await Zastepstwa.find({});
    res.json(zastepstwa);
  } catch (err) {
    res.status(500).json({ error: "Błąd serwera" });
  }
});

module.exports = router;
