const express = require("express");
const router = express.Router();
const Nauczyciel = require("../models/Nauczyciel");

router.get("/nauczyciele", async (req, res) => {
  try {
    const nauczyciele = await Nauczyciel.find({});
    res.json(nauczyciele);
  } catch (err) {
    res.status(500).json({ error: "Błąd serwera" });
  }
});

module.exports = router;
