const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const ZastepstwaSchema = new Schema(
    {
    data: Date,
    klasa: String,
    godzina_lekcyjna: Number,
    nauczyciel_stary: String,
    nauczyciel_nowy: String,
    uwagi: String
    },
    { collection: "zastepstwa" }
);

module.exports = mongoose.model("Zastepstwa", ZastepstwaSchema);

