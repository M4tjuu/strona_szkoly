const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const NauczycielSchema = new Schema(
    {
        imie: String,
        nazwisko: String,
        inicjaly: String
    },
    { collection: "nauczyciele" }
);

module.exports = mongoose.model("Nauczyciel", NauczycielSchema);
