import { NavLink } from 'react-router-dom';
import Home from './pages/home.jsx';

function App() {

  return (
    <>
      <Home />
    </>
  )
}

export default App
