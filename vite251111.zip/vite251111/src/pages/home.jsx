import React from "react";
import Header from "../components/Header";
import RedButton from "../components/RedButton";
import StrefaKarta from "../components/StrefaKarta";
import InicjatywyDiv from "../components/InicjatywyDiv";
import WspolpracaImg from "../components/WspolpracaImg";
import HomeH2 from "../components/HomeH2";

export default function Home() {
return ( 
  <main>
    <Header />
      {/* Sekcja 1 – O szkole */}
      <section className="tw:w-full tw:px-[5%] tw:lg:px-[10%] tw:py-8 tw:bg-[#F7F7F7]">
        <div className="tw:float-right tw:mb-4">
          <RedButton name="O szkole" link="/historia"/>
        </div>
        <div className="tw:w-full tw:h-[200px] tw:md:h-[300px] tw:lg:h-[400px] tw:xl:h-[500px] tw:overflow-hidden tw:rounded-lg">
          <img src="/img/szkola.png" alt="Budynek szkoły" className="tw:w-full tw:h-full tw:object-cover tw:object-bottom" />
        </div>
      </section>

      {/* Sekcja 2 – Strefy */}
      <section className="tw:w-full tw:px-[5%] tw:lg:px-[10%] tw:py-8 tw:bg-white tw:flex tw:flex-col tw:lg:flex-row tw:justify-between tw:gap-8">
        {/* uczencropped.png to niezcropowany uczen po prostu nazwa zmieniona */}
        <StrefaKarta who="uczen" title="Strefa ucznia" description="Sprawdź aktualności, zmiany w planie lekcji, najbliższe dni wolne" link="/StrefaUcznia" />
        <StrefaKarta who="rodzic" title="Strefa rodzica" description="Informacje o składkach, zebraniach, wycieczkach" link="/StrefaRodzica" />
        <StrefaKarta who="kandydat" title="Strefa kandydata" description="Dowiedz się więcej o poszczególnych kierunkach" link="/StrefaKandydata" />
      </section>

      {/* Sekcja 3 – Inicjatywy uczniowskie */}
      <section className="tw:w-full tw:px-[5%] tw:lg:px-[10%] tw:py-8 tw:bg-[#F7F7F7] tw:flex tw:flex-wrap tw:justify-between">
        {/* Obrazek */}
        <div className="tw:w-full tw:2xl:w-[55%]">
          <img src="/img/inicjatywa.png" alt="Inicjatywa" className="tw:w-full tw:rounded-lg"
          />
        </div>

        {/* Tekst */}
        <div className="tw:w-full tw:2xl:w-[45%] tw:mt-8 tw:2xl:mt-0 tw:p-0 tw:2xl:px-5">
          <HomeH2 title="Inicjatywy uczniowskie" />
          <InicjatywyDiv title="Wolontariat" 
            content="Dołącz do zespołu organizującego m.in. zbiórki pieniędzy naszczytne cele." />
          <InicjatywyDiv title="Samorząd uczniowski" 
            content="Masz pomysły na zmiany? Poznaj inne osoby, które biorą sprawy we własne ręce." />
          <InicjatywyDiv title="Koła zainteresowań" 
            content="Chcesz rozwijać swoje pasje? Dołącz do kół uczniowskich lub załóż własne!" />
          <div className="tw:p-1.5 tw:mt-0">
            <RedButton name="Dowiedz się więcej" link="https://wisniowasu.pl/" />
          </div>
        </div>
      </section>

      {/* Sekcja 4 – Firmy współpracujące */}
      <section className="tw:w-full tw:px-[5%] tw:lg:px-[10%] tw:py-8 tw:bg-white tw:clear-both">
        <div className="tw:text-center tw:sm:text-left">
          <HomeH2 title="Firmy współpracujące" />
        </div>
        <div className="tw:grid tw:grid-cols-2 tw:2xl:grid-cols-4 tw:gap-6 tw:justify-items-center">
          <WspolpracaImg firma="cisco" />
          <WspolpracaImg firma="polaris" />
          <WspolpracaImg firma="pzu" />
          <WspolpracaImg firma="toyota" />
        </div>
      </section>
    </main>
  );
}
