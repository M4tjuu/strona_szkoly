import { useState } from "react";
import { data } from "react-router";
 
export default function TestForm() {
    const [inputs, setInputs] = useState({
        imie: "",
        nazwisko: "",
        wiek: 0,
    });
 
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({ ...values, [name]: value }))
    }
 
 
    //odbieranie danych i wysyłanie do serwera
    const handleSubmit = (event) => {
        event.preventDefault();
        //pokazywanie wysłanych danych (jak ok można usunąć)
        alert(JSON.stringify(inputs));
        //wysyłanie Postem w JSON
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(inputs)
        };
        fetch('http://localhost:3000/add', requestOptions)
            .then(response => response.json())
            .then(data => console.log(data.message));
    }  
 
 
 
    return (
        <>
            <form onSubmit={handleSubmit}>
                <label>Imie</label>
                <input type="text" name="imie" value={inputs.imie} onChange={handleChange} />
                <label>Nazwisko</label>
                <input type="text" name="nazwisko" value={inputs.nazwisko} onChange={handleChange} />
                <label>Wiek</label>
                <input type="number" name="wiek" value={inputs.wiek} onChange={handleChange} />
                <input type="submit"/>
            </form>
        </>
    );
}