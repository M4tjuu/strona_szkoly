import React from "react";
import DokumentLink from "../components/dokumentLink";

export default function Plan() {
return (
  <main className="tw:bg-[#F7F7F7] tw:mx-[5%] tw:lg:mx-[10%] tw:my-8 tw:p-6 tw:rounded-2xl tw:shadow-md">
    <div className="w-auto mb-10 mx-[0%] lg:mb-16 lg:mx-[0%] clear-both">
      <div className="container">
        <div className="">
          <h1 className="tw:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:font-extrabold tw:leading-none tw:tracking-tight tw:text-center tw:mb-8">
            Dokumenty szkoły
          </h1>

          <div className="row gy-4">
            {/* Kolumna lewa */}
            <div className="col-md-6">
              <h4 className="fw-bold mb-3">Statut</h4>
              <ul className="list-unstyled">
                <DokumentLink name="STATUT_DN_22-02-2016" file="STATUT_DN_22-02-2016.docx" />
              </ul>

              <h4 className="fw-bold mt-4 mb-3">WSO i PSO</h4>
              <ul className="list-unstyled">
                <DokumentLink name="Matematyka" file="matematyka.docx" />
                <DokumentLink name="Fizyka poziom rozszerzony" file="fizyka_poziom_rozszerzony.docx" />
                <DokumentLink name="Fizyka poziom podstawowy" file="fizyka_poziom_podstawowy.docx" />
                <DokumentLink name="Informatyka" file="informatyka.docx" />
                <DokumentLink name="Język angielski" file="jezyk_angielski.docx" />
                <DokumentLink name="Język polski" file="jezyk_polski.docx" />
                <DokumentLink name="Biologia" file="biologia.docx" />
                <DokumentLink name="Chemia" file="chemia.docx" />
                <DokumentLink name="Geografia" file="geografia.docx" />
                <DokumentLink name="Historia" file="historia.docx" />
                <DokumentLink name="Przedmiotowy system oceniania – języki obce II" file="jezyki_obce_II.docx" />
                <DokumentLink name="Przedmioty zawodowe SOJM" file="przedmioty_zawodowe_SOJM.docx" />
                <DokumentLink name="System oceniania jednostek modułowych" file="system_oceniania_jednostek_modulowych.docx" />
              </ul>
              <p className="tw:text-sm tw:text-gray-600">
                *WSO jest częścią statutu szkoły
              </p>
            </div>

            {/* Kolumna prawa */}
            <div className="col-md-6">
              <h4 className="fw-bold mb-3">Kalendarz roku szkolnego</h4>
              <ul className="list-unstyled">
                <DokumentLink name="Kalendarz 2025/2026" file="kalendarz2025_2026.docx" />
              </ul>

              <h4 className="fw-bold mt-4 mb-3">Plany nauczania</h4>
              <ul className="list-unstyled">
                <DokumentLink name="Informatyk" file="informatyk.docx" />
                <DokumentLink name="Informatyk dwujęzyczny" file="informatyk_dwujezyczny.docx" />
                <DokumentLink name="Programista" file="programista.docx" />
                <DokumentLink name="Mechatronik" file="mechatronik.docx" />
              </ul>

              <h4 className="fw-bold mt-4 mb-3">Regulaminy i instrukcje BHP</h4>
              <ul className="list-unstyled">
                <DokumentLink
                    name="Regulamin bezpieczeństwa i higieny pracy TM1" file="Regulamin_BHP_TM1.docx"/>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
);
}
