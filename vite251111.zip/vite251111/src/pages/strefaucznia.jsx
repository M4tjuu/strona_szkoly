import React from "react";
import RedButton from "../components/RedButton";
import { Card, Button } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFacebook } from "@fortawesome/free-brands-svg-icons";
import { faChalkboardTeacher, faClipboardList } from "@fortawesome/free-solid-svg-icons";

export default function Historia() {
  return (
    <main className="tw:bg-[#F7F7F7] tw:mx-[5%] tw:lg:mx-[10%] tw:my-8 tw:p-6 tw:rounded-2xl tw:shadow-md">
      <h1 className="tw:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:font-extrabold tw:text-center tw:mb-8">
        Strefa ucznia
      </h1>

      <p className="tw:text-center tw:text-gray-700 tw:text-lg tw:mb-10">
        Sprawdź aktualności, zmiany w planie lekcji oraz najbliższe dni wolne.
      </p>

      <div className="row g-4">
        {/* --- KARTA 1 --- */}
        <div className="col-12 col-md-4">
          <Card className="h-100 tw:shadow-sm tw:hover:shadow-lg tw:transition-shadow tw:duration-300 tw:rounded-xl tw:overflow-hidden">
            <div className="tw:h-48 tw:w-full tw:bg-gray-200 tw:flex tw:items-center tw:justify-center">
              {/* Propozycja obrazka: logo Facebooka lub zdjęcie szkolnego wydarzenia */}
              <FontAwesomeIcon icon={faFacebook} className="tw:text-[#1877F2] tw:text-6xl" />
            </div>
            <Card.Body className="tw:text-center tw:p-5">
              <Card.Title className="tw:text-2xl tw:font-bold tw:mb-3 tw:text-gray-900">
                Aktualności
              </Card.Title>
              <Card.Text className="tw:text-gray-700 tw:mb-4">
                Bądź na bieżąco z życiem szkoły - wydarzenia, ogłoszenia i zdjęcia znajdziesz na naszym Facebooku.
              </Card.Text>
              <Button
                variant="primary"
                className="tw:bg-[#1877F2] tw:border-none tw:rounded-full tw:px-4 tw:py-2 tw:font-semibold"
                href="https://www.facebook.com/Technikum.Mechatroniczne.nr.1"
                target="_blank"
                rel="noopener noreferrer"
              >
                Odwiedź Facebooka
              </Button>
            </Card.Body>
          </Card>
        </div>

        {/* --- KARTA 2 --- */}
        <div className="col-12 col-md-4">
          <Card className="h-100 tw:shadow-sm tw:hover:shadow-lg tw:transition-shadow tw:duration-300 tw:rounded-xl tw:overflow-hidden">
            <div className="tw:h-48 tw:w-full tw:bg-gray-200 tw:flex tw:items-center tw:justify-center">
              {/* Propozycja obrazka: plan lekcji, tablica szkolna */}
              <FontAwesomeIcon icon={faChalkboardTeacher} className="tw:text-gray-800 tw:text-6xl" />
            </div>
            <Card.Body className="tw:text-center tw:p-5">
              <Card.Title className="tw:text-2xl tw:font-bold tw:mb-3 tw:text-gray-900">
                Zmiany w planie
              </Card.Title>
              <Card.Text className="tw:text-gray-700 tw:mb-4">
                Sprawdź aktualny plan lekcji i zastępstwa dla swojej klasy na najbliższy tydzień.
              </Card.Text>
              <div className="tw:flex tw:justify-center tw:gap-3">
                <Button
                  variant="secondary"
                  className="tw:rounded-full tw:px-4 tw:py-2 tw:font-semibold"
                  href="/plan"
                >
                  Plan lekcji
                </Button>
                <Button
                  variant="outline-secondary"
                  className="tw:rounded-full tw:px-4 tw:py-2 tw:font-semibold"
                  href="/zastepstwa"
                >
                  Zastępstwa
                </Button>
              </div>
            </Card.Body>
          </Card>
        </div>

        {/* --- KARTA 3 --- */}
        <div className="col-12 col-md-4">
          <Card className="h-100 tw:shadow-sm tw:hover:shadow-lg tw:transition-shadow tw:duration-300 tw:rounded-xl tw:overflow-hidden">
            <div className="tw:h-48 tw:w-full tw:bg-gray-200 tw:flex tw:items-center tw:justify-center">
              {/* Propozycja obrazka: kalendarz, szkolne notatki */}
              <FontAwesomeIcon icon={faClipboardList} className="tw:text-[#93041C] tw:text-6xl" />
            </div>
            <Card.Body className="tw:text-center tw:p-5">
              <Card.Title className="tw:text-2xl tw:font-bold tw:mb-3 tw:text-gray-900">
                Najbliższe dni wolne
              </Card.Title>
              <Card.Text className="tw:text-gray-700 tw:mb-4">
                Zobacz kalendarz roku szkolnego, aby sprawdzić nadchodzące święta i dni wolne.
              </Card.Text>
              <Button 
                download
                variant="danger"
                className="tw:rounded-full tw:px-4 tw:py-2 tw:text-white tw:font-semibold"
                href="/dokumenty/kalendarz2025_2026.docx"
              >
                Kalendarz roku
              </Button>
            </Card.Body>
          </Card>
        </div>
      </div>
    </main>
  );
}
