import React from "react";

export default function Zastepstwa() {
  const data = "12.11.2025 (środa)";

  const zastepstwa = [
    {
      nauczyciel: "Anna Wiśniowa",
      lekcje: [
        { nr: 1, opis: "1 lb(2) — Uczniowie przychodzą później", zastepca: "", uwagi: "" },
        { nr: 2, opis: "1 lb(2) — Uczniowie przychodzą później", zastepca: "", uwagi: "" },
        { nr: 3, opis: "2 lb(2) — Język niemiecki, 417", zastepca: "Jan Kowalski", uwagi: "" },
        { nr: 4, opis: "2 lb(2) — Język niemiecki, 417", zastepca: "Jan Kowalski", uwagi: "" },
        { nr: 5, opis: "Język drugi 1TA/1TB — Czytelnia", zastepca: "", uwagi: "" },
        { nr: 6, opis: "1 lb(1) — Uczniowie zwolnieni do domu", zastepca: "", uwagi: "" },
        { nr: 7, opis: "1 lb(1) — Uczniowie zwolnieni do domu", zastepca: "", uwagi: "" },
      ],
    },
    {
      nauczyciel: "Adam Sigma",
      lekcje: [
        { nr: 7, opis: "4 TA — Historia, 313", zastepca: "Jan Kowalski", uwagi: "Za ostatnią lekcję" },
        { nr: 8, opis: "3 TM — Bez konsekwencji (nieobecny oddział nauczyciela)", zastepca: "", uwagi: "" },
      ],
    },
    {
      nauczyciel: "Andrzej Spokojny",
      lekcje: [
        { nr: 2, opis: "2 TC — Fizyka, 302", zastepca: "Jan Kowalski", uwagi: "Zajęcia łączone z 2TD" },
        { nr: 4, opis: "1 TB — Matematyka, 312", zastepca: "Jan Kowalski", uwagi: "Zastępstwo doraźne" },
      ],
    },
  ];

  return (
    <main className="tw:bg-[#F7F7F7] tw:mx-[5%] tw:lg:mx-[10%] tw:my-8 tw:p-6 tw:rounded-2xl tw:shadow-md">
      <h1 className="tw:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:font-extrabold tw:leading-none tw:mb-6">
        Zastępstwa w dniu {data}
      </h1>

      <div className="tw:space-y-10">
        {zastepstwa.map((nauczyciel, i) => (
          <section key={i} className="tw:bg-white tw:rounded-xl tw:shadow-sm tw:p-4">
            <h2 className="tw:text-2xl tw:font-bold tw:text-dark tw:mb-4">
              {nauczyciel.nauczyciel}
            </h2>

            <div className="tw:overflow-x-auto">
              <table className="tw:w-full tw:text-center tw:border-collapse">
                <thead className="tw:bg-gray-200">
                  <tr>
                    <th className="tw:py-2 tw:px-3">Lekcja</th>
                    <th className="tw:py-2 tw:px-3">Opis</th>
                    <th className="tw:py-2 tw:px-3">Zastępca</th>
                    <th className="tw:py-2 tw:px-3">Uwagi</th>
                  </tr>
                </thead>
                <tbody>
                  {nauczyciel.lekcje.map((lekcja) => (
                    <tr key={lekcja.nr} className="tw:border-b tw:border-gray-200">
                      <td className="tw:py-2 tw:px-3 tw:font-semibold tw:bg-gray-50">{lekcja.nr}</td>
                      <td className="tw:py-2 tw:px-3">{lekcja.opis}</td>
                      <td className="tw:py-2 tw:px-3">{lekcja.zastepca || "-"}</td>
                      <td className="tw:py-2 tw:px-3">{lekcja.uwagi || "-"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        ))}
      </div>

      <p className="tw:text-md tw:text-gray-600 tw:mt-8 tw:text-left">
        Ostatnia aktualizacja: 11.11.2025, godz. 18:45
      </p>
    </main>
  );
}
