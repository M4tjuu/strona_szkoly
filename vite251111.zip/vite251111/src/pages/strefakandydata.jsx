import React from "react";
import { Card, Button } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBookOpen, faChartLine, faGraduationCap } from "@fortawesome/free-solid-svg-icons";

export default function StrefaKandydata() {
  return (
    <main className="tw:bg-[#F7F7F7] tw:mx-[5%] tw:lg:mx-[10%] tw:my-8 tw:p-6 tw:rounded-2xl tw:shadow-md">
      <h1 className="tw:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:font-extrabold tw:text-center tw:mb-8">
        Strefa kandydata
      </h1>

      <p className="tw:text-center tw:text-gray-700 tw:text-lg tw:mb-10">
        Zdobądź najważniejsze informacje o kierunkach, wymaganiach rekrutacyjnych i sukcesach szkoły.
      </p>

      <div className="row g-4">
        {/* --- KARTA 1: Kierunki kształcenia --- */}
        <div className="col-12 col-md-6">
          <Card className="tw:h-full tw:shadow-sm tw:hover:shadow-lg tw:transition-shadow tw:duration-300 tw:rounded-xl tw:overflow-hidden">
            <div className="tw:h-48 tw:w-full tw:bg-gray-200 tw:flex tw:items-center tw:justify-center">
              <FontAwesomeIcon icon={faBookOpen} className="tw:text-[#93041C] tw:text-6xl" />
            </div>
            <Card.Body className="tw:text-center tw:p-5">
              <Card.Title className="tw:text-2xl tw:font-bold tw:mb-3 tw:text-gray-900">
                Kierunki kształcenia
              </Card.Title>
              <Card.Text className="tw:text-gray-700 tw:mb-4">
                Poznaj wszystkie kierunki techniczne dostępne w naszej szkole i na podstawie planów nauczania, wybierz ten, który najbardziej Cię interesuje
              </Card.Text>
              <Button
                variant="danger"
                className="tw:rounded-full tw:px-4 tw:py-2 tw:font-semibold"
                href="/dokumenty"
              >
                Zobacz kierunki
              </Button>
            </Card.Body>
          </Card>
        </div>

        {/* --- KARTA 2: Osiągnięcia szkoły --- */}
        <div className="col-12 col-md-6">
          <Card className="tw:h-full tw:shadow-sm tw:hover:shadow-lg tw:transition-shadow tw:duration-300 tw:rounded-xl tw:overflow-hidden">
            <div className="tw:h-48 tw:w-full tw:bg-gray-200 tw:flex tw:items-center tw:justify-center">
              <FontAwesomeIcon icon={faChartLine} className="tw:text-gray-800 tw:text-6xl" />
            </div>
            <Card.Body className="tw:text-center tw:p-5">
              <Card.Title className="tw:text-2xl tw:font-bold tw:mb-3 tw:text-gray-900">
                Progi, wyniki i sukcesy
              </Card.Title>
              <Card.Text className="tw:text-gray-700 tw:mb-4">
                Zobacz, jak nasi uczniowie wypadają na egzaminach maturalnych i zawodowych oraz sprawdź rekrutacyjne progi punktowe z ubiegłych lat.
              </Card.Text>
              <Button
                variant="secondary"
                className="tw:rounded-full tw:px-4 tw:py-2 tw:font-semibold"
                href="https://waszaedukacja.pl/ponadgimnazjalne/technikum-mechatroniczne-nr-1-warszawa-364"
                target="_blank"
                rel="noopener noreferrer"
              >
                Dowiedz się więcej
              </Button>
            </Card.Body>
          </Card>
        </div>
      </div>
    </main>
  );
}
