import React from "react";

export default function StrefaKarta({title}) {
    return (
        <h2 className="tw:text-2xl tw:sm:text-4xl tw:lg:text-5xl tw:text-gray-900 tw:mb-5 tw:font-extrabold tw:leading-none tw:tracking-tight">
            {title}
        </h2>
  );
}
