import React from "react";
import { NavLink } from 'react-router-dom';
            
export default function redButton({name, link}) {
    return (
    <NavLink to={link} className="tw:bg-[#93041C] tw:text-white tw:px-4 tw:py-2 tw:rounded-md tw:font-bold tw:no-underline tw:inline-block tw:hover:opacity-100 tw:hover:scale-105 tw:transition-transform">
        {name}
    </NavLink>
/*
    <a
        href="/"
        className="tw:bg-[#93041C] tw:text-white tw:px-4 tw:py-2 tw:rounded-md tw:font-bold tw:no-underline tw:hover:opacity-60 tw:transition tw:inline-block"
    >
        Dowiedz się więcej <i className="fa-solid fa-arrow-right"></i>
    </a>

    <li>
        <a
        href={`dokumenty/${file}`}
        download
        className="text-dark text-decoration-underline"
        >
        {name}
        </a>
    </li>
*/
    );
}
            