import React from "react";

  const plan = [
    { godzina: "8:00 - 8:45", pon: "Matematyka JK 312", wt: "J. polski JK 305", sr: "Historia JK 310", czw: "Fizyka JK 301", pt: "Biologia JK 316" },
    { godzina: "8:50 - 9:35", pon: "Informatyka JK 317", wt: "Matematyka JK 312", sr: "Chemia JK 308", czw: "J. angielski JK 306", pt: "WF JK 303" },
    { godzina: "9:40 - 10:25", pon: "J. polski JK 305", wt: "Geografia JK 307", sr: "Biologia JK 316", czw: "Matematyka JK 312", pt: "Fizyka JK 301" },
    { godzina: "10:30 - 11:15", pon: "Chemia JK 308", wt: "WF JK 303", sr: "J. angielski JK 306", czw: "Historia JK 310", pt: "Informatyka JK 317" },
    { godzina: "11:35 - 12:20", pon: "Biologia JK 316", wt: "J. polski JK 305", sr: "Matematyka JK 312", czw: "Geografia JK 307", pt: "Chemia JK 308" },
    { godzina: "12:40 - 13:25", pon: "Historia JK 310", wt: "J. angielski JK 306", sr: "WF JK 303", czw: "Biologia JK 316", pt: "Matematyka JK 312" },
    /* 
    { godzina: "13:30 - 14:15", pon: "Biologia JK 316", wt: "J. polski JK 305", sr: "Matematyka JK 312", czw: "Geografia JK 307", pt: "Chemia JK 308" },
    { godzina: "14:20 - 15:05", pon: "Historia JK 310", wt: "J. angielski JK 306", sr: "WF JK 303", czw: "Biologia JK 316", pt: "Matematyka JK 312" },
    */
  ];


export default function Plan() {
return (
  <main className="tw:bg-[#F7F7F7] tw:mx-[5%] tw:lg:mx-[10%] tw:my-8 tw:p-6 tw:rounded-2xl tw:shadow-md">
    <h1 className="tw:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:font-extrabold tw:leading-none tw:tracking-tight tw:text-center tw:mb-6">Wybierz klasę lub nauczyciela</h1>

  {/* Pole wyboru */}
  <div className="tw:flex tw:justify-start tw:mb-8">
    <select
      className="form-select tw:w-48 tw:p-2 tw:rounded-md tw:border tw:border-gray-300 tw:font-semibold" defaultValue="5tb">
      <option value="5tb">5TB</option>
      <option value="1ta">1TA</option>
      <option value="2tc">2TC</option>
      <option value="kowalski">Jan Kowalski</option>
    </select>
  </div>

    {/* Tabela planu */}
    <div className="tw:overflow-x-auto">
      <table className="table table-striped tw:w-full tw:text-center align-middle">
        <thead className="tw:bg-gray-200">
          <tr>
            <th className="tw:sticky tw:left-0 tw:z-10">Godzina</th>
            <th>Poniedziałek</th>
            <th>Wtorek</th>
            <th>Środa</th>
            <th>Czwartek</th>
            <th>Piątek</th>
          </tr>
        </thead>
        <tbody>
          {plan.map((lekcja, i) =>
            lekcja.przerwa ? (
              <tr key={i} className="tw:bg-yellow-100">
                <td colSpan={6} className="tw:font-semibold">{lekcja.przerwa} ({lekcja.godzina})</td>
              </tr>
            ) : (
              <tr key={i}>
                <td className="tw:font-medium tw:sticky tw:left-0 tw:z-10">{lekcja.godzina}</td>
                <td>{lekcja.pon}</td>
                <td>{lekcja.wt}</td>
                <td>{lekcja.sr}</td>
                <td>{lekcja.czw}</td>
                <td>{lekcja.pt}</td>
              </tr>
            )
          )}
        </tbody>
      </table>
    </div>

    <p className="tw:text-md tw:text-gray-600 tw:mt-2 tw:text-left">
      Plan obowiązuje od 16.09.2025.
    </p>
  </main>
);
};
