import React from "react";
import Header from "../components/Header";

export default function Home() {
return ( <main> <Header />
      {/* Sekcja 1 – O szkole */}
      <section className="tw:w-full tw:px-[5%] tw:lg:px-[10%] tw:py-8 tw:bg-[#F7F7F7]">
        <a
          href="/"
          className="tw:float-right tw:bg-[#93041C] tw:text-white tw:px-4 tw:py-2 tw:rounded-md tw:font-bold tw:no-underline tw:hover:opacity-60 tw:transition tw:mb-4 tw:inline-block"
        >
          O szkole <i className="fa-solid fa-arrow-right"></i>
        </a>
        <div className="tw:w-full tw:h-[200px] tw:md:h-[300px] tw:lg:h-[400px] tw:xl:h-[500px] tw:overflow-hidden tw:rounded-lg">
          <img
            src="/img/szkola.png"
            alt="Budynek szkoły"
            className="tw:w-full tw:h-full tw:object-cover tw:object-bottom"
          />
        </div>
      </section>

      {/* Sekcja 2 – Strefy */}
      <section className="tw:w-full tw:px-[5%] tw:lg:px-[10%] tw:py-8 tw:bg-white tw:flex tw:flex-col tw:lg:flex-row tw:justify-between tw:gap-8">
        {/* KARTA 1 */}
        <div className="tw:w-full tw:lg:w-[30%] tw:min-w-[250px]">
          <a href="/" className="tw:block tw:hover:scale-105 tw:transition-transform tw:mb-4 tw:sm:mb-5 tw:md:mb-6 tw:lg:mb-4">
            <img
              src="/img/uczen.png"
              alt="Uczeń"
              className="tw:w-full tw:h-auto tw:rounded-lg"
            />
          </a>
          <h2 className="tw:text-2xl tw:lg:text-3xl tw:text-gray-900 tw:font-extrabold tw:leading-none tw:tracking-tight tw:mb-1 tw:mt-3">
            Strefa ucznia
          </h2>
          <p className="tw:text-xl tw:lg:text-2xl">
            Sprawdź aktualności, zmiany w planie lekcji, najbliższe dni wolne
          </p>
        </div>

        {/* KARTA 2 */}
        <div className="tw:w-full tw:lg:w-[30%] tw:min-w-[250px]">
          <a href="/" className="tw:block tw:hover:scale-105 tw:transition-transform tw:mb-4 tw:sm:mb-5 tw:md:mb-6 tw:lg:mb-4">
            <img
              src="/img/rodziccropped.png"
              alt="Rodzic"
              className="tw:w-full tw:h-auto tw:rounded-lg"
            />
          </a>
          <h2 className="tw:text-2xl tw:lg:text-3xl tw:text-gray-900 tw:font-extrabold tw:leading-none tw:tracking-tight tw:mb-1 tw:mt-3">
            Strefa rodzica
          </h2>
          <p className="tw:text-xl tw:sm:text-xl tw:lg:text-2xl">
            Informacje o składkach, zebraniach, wycieczkach
          </p>
        </div>

        {/* KARTA 3 */}
        <div className="tw:w-full tw:lg:w-[30%] tw:min-w-[250px]">
          <a href="/" className="tw:block tw:hover:scale-105 tw:transition-transform tw:mb-4 tw:sm:mb-5 tw:md:mb-6 tw:lg:mb-4">
            <img
              src="/img/kandydatcropped.png"
              alt="Kandydat"
              className="tw:w-full tw:h-auto tw:rounded-lg"
            />
          </a>
          <h2 className="tw:text-2xl tw:lg:text-3xl tw:text-gray-900 tw:font-extrabold tw:leading-none tw:tracking-tight tw:mb-1 tw:mt-3">
            Strefa kandydata
          </h2>
          <p className="tw:text-xl tw:sm:text-xl tw:lg:text-2xl">
            Dowiedz się więcej o poszczególnych kierunkach
          </p>
        </div>
      </section>


      {/* Sekcja 3 – Inicjatywy uczniowskie */}
      <section className="tw:w-full tw:px-[5%] tw:lg:px-[10%] tw:py-8 tw:bg-[#F7F7F7] tw:flex tw:flex-wrap tw:justify-between">
        {/* Obrazek */}
        <div className="tw:w-full tw:2xl:w-[55%]">
          <img
            src="/img/inicjatywa.png"
            alt="Inicjatywa"
            className="tw:w-full tw:rounded-lg"
          />
        </div>

        {/* Tekst */}
        <div className="tw:w-full tw:2xl:w-[45%] tw:mt-8 tw:2xl:mt-0 tw:p-0 tw:2xl:px-5">
          <h2 className="tw:text-2xl tw:sm:text-4xl tw:lg:text-5xl tw:text-gray-900 tw:mb-5 tw:font-extrabold tw:leading-none tw:tracking-tight">
            Inicjatywy uczniowskie
          </h2>

          <div className="tw:p-2">
            <h3 className="tw:text-xl tw:sm:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:mb-2 tw:font-bold tw:leading-none tw:tracking-tight">
              Wolontariat
            </h3>
            <p className="tw:text-lg tw:sm:text-2xl tw:lg:text-3xl tw:leading-none">
              Dołącz do zespołu organizującego m.in. zbiórki pieniędzy na
              szczytne cele.
            </p>
          </div>

          <div className="tw:p-2">
            <h3 className="tw:text-xl tw:sm:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:mb-2 tw:font-bold tw:leading-none tw:tracking-tight">
              Samorząd uczniowski
            </h3>
            <p className="tw:text-lg tw:sm:text-2xl tw:lg:text-3xl tw:leading-none">
              Masz pomysły na zmiany? Poznaj inne osoby, które biorą sprawy we
              własne ręce.
            </p>
          </div>

          <div className="tw:p-2">
            <h3 className="tw:text-xl tw:sm:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:mb-2 tw:font-bold tw:leading-none tw:tracking-tight">
              Koła zainteresowań
            </h3>
            <p className="tw:text-lg tw:sm:text-2xl tw:lg:text-3xl tw:leading-none">
              Chcesz rozwijać swoje pasje? Dołącz do kół uczniowskich lub
              załóż własne!
            </p>
          </div>

          <div className="tw:p-2 tw:mt-6">
            <a
              href="/"
              className="tw:bg-[#93041C] tw:text-white tw:px-4 tw:py-2 tw:rounded-md tw:font-bold tw:no-underline tw:hover:opacity-60 tw:transition tw:inline-block"
            >
              Dowiedz się więcej <i className="fa-solid fa-arrow-right"></i>
            </a>
          </div>
        </div>
      </section>

      {/* Sekcja 4 – Firmy współpracujące */}
      <section className="tw:w-full tw:px-[5%] tw:lg:px-[10%] tw:py-8 tw:bg-white tw:clear-both">
        <h2 className="tw:text-4xl tw:sm:text-5xl tw:lg:text-5xl tw:text-gray-900 tw:mb-6 tw:font-extrabold tw:leading-none tw:tracking-tight tw:text-center tw:sm:text-left">
          Firmy współpracujące
        </h2>
        <div className="tw:grid tw:grid-cols-2 tw:2xl:grid-cols-4 tw:gap-6 tw:justify-items-center">
          <img
            src="/img/cisco.png"
            alt="Cisco"
            className="tw:max-h-300 tw:mix-blend-multiply tw:brightness-110"
          />
          <img
            src="/img/polaris.png"
            alt="Polaris"
            className="tw:max-h-300 tw:mix-blend-multiply tw:brightness-110"
          />
          <img
            src="/img/pzu.png"
            alt="Pzu"
            className="tw:max-h-300 tw:mix-blend-multiply tw:brightness-110"
          />
          <img
            src="/img/toyota.png"
            alt="Toyota"
            className="tw:max-h-300 tw:mix-blend-multiply tw:brightness-110"
          />
        </div>
      </section>
    </main>
  );
}
