import React from "react";

export default function Plan() {
return ( <main className="tw:px-[5%] tw:lg:px-[10%] tw:py-10 tw:bg-white"> <h1 className="tw:text-3xl tw:font-bold tw:mb-6 tw:text-[#93041C]">Plan lekcji</h1> <p>Plan lekcji dostępny jest na platformie Vulcan.</p> <a
     href="https://uonetplus.vulcan.net.pl/warszawamokotow"
     target="_blank"
     rel="noopener noreferrer"
     className="tw:bg-[#93041C] tw:text-white tw:px-4 tw:py-2 tw:rounded-md tw:font-bold tw:no-underline tw:hover:opacity-60 tw:transition tw:mt-4 tw:inline-block"
   >
Przejdź do dziennika </a> </main>
);
}
