/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        tm1Blue: "#003366",       // ciemny niebieski (dobry kontrast z białym)
        tm1Light: "#f5f8fa",      // jasny szary
        tm1Gray: "#333333",        // ciemny szary do stopki / tekstu
        tm1Accent: "#007bff",      // przyciski, linki
      },
    },
  },
  plugins: [],
};
