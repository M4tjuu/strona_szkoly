import { Link } from "react-router-dom";

export default function QuickLinks() {
  const links = [
    { title: "Plan lekcji", to: "/plan" },
    { title: "E-dziennik", to: "https://eduvulcan.pl/" },
    { title: "Rekrutacja", to: "/rekrutacja" },
    { title: "Kontakt", to: "/kontakt" },
  ];

  return (
    <section className="py-5 bg-light">
      <div className="container">
        <div className="row g-3 g-md-4 text-center">
          {links.map((link, i) => (
            <div key={i} className="col-6 col-md-3">
              <Link
                to={link.to}
                className="d-block p-4 bg-white rounded shadow-sm text-decoration-none text-primary fw-semibold transition"
                style={{ transition: "all 0.3s", backgroundColor: "#ffffff" }}
                onMouseEnter={e => e.currentTarget.style.backgroundColor = "#e0e8f0"}
                onMouseLeave={e => e.currentTarget.style.backgroundColor = "#ffffff"}
              >
                <span className="text-dark">{link.title}</span>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
