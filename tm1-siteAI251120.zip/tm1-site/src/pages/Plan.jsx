import React from "react";

export default function Plan() {
  const dniTygodnia = ["Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek"];
  const godziny = ["08:00-08:45", "08:55-09:40", "09:50-10:35", "10:50-11:35", "11:45-12:30", "12:40-13:25"];

  // przykładowe lekcje
  const plan = [
    ["Matematyka", "Fizyka", "Język angielski", "WF", "Informatyka", "Chemia"],
    ["Język polski", "Historia", "Matematyka", "Technika", "WF", "Fizyka"],
    ["Informatyka", "Język niemiecki", "Matematyka", "WF", "Chemia", "Technika"],
    ["Język polski", "Fizyka", "Historia", "Matematyka", "WF", "Informatyka"],
    ["Technika", "Matematyka", "Chemia", "Język angielski", "WF", "Język niemiecki"],
  ];

  return (
    <div className="bg-white container py-5">
      <h1 className="mb-4 text-[#003366]">Plan lekcji</h1>
      <p className="mb-4">Przykładowy plan lekcji dla klas technikum mechatronicznego.</p>

      <div className="table-responsive">
        <table className="table table-bordered text-center">
          <thead className="table-light">
            <tr>
              <th>Godzina / Dzień</th>
              {dniTygodnia.map((dzien, i) => (
                <th key={i}>{dzien}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {godziny.map((godzina, i) => (
              <tr key={i}>
                <td className="fw-bold">{godzina}</td>
                {plan.map((dzienLekcji, j) => (
                  <td key={j}>{dzienLekcji[i]}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-muted">
        Uwaga: jest to poglądowy plan lekcji, faktyczne lekcje mogą się różnić w zależności od klasy i semestru.
      </p>
    </div>
  );
}
