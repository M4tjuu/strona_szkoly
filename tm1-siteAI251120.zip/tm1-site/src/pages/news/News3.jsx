import React from "react";

export default function News3() {
  return (
    <div className="container py-5">
      <h1 className="mb-3 text-[#003366]">Nowoczesne pracownie mechatroniczne</h1>
      <p className="text-muted">5 listopada 2025</p>
      <img
        src="/src/assets/news3.jpg"
        alt="Pracownie Mechatroniczne"
        className="img-fluid rounded mb-4"
        style={{ maxHeight: "400px", objectFit: "cover", width: "100%" }}
      />
      <p>
        Szkoła otworzyła nowe laboratoria do nauki programowania robotów i automatyki przemysłowej.  
        Uczniowie mogą korzystać z nowoczesnych stanowisk, w tym robotów przemysłowych, drukarek 3D oraz zestawów automatyki.
      </p>
      <p>
        Pracownie służą zarówno do zajęć praktycznych, jak i projektów konkursowych, a także współpracy z lokalnymi firmami z branży technologicznej.
      </p>
    </div>
  );
}
