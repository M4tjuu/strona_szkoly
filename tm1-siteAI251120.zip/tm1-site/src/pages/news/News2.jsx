import React from "react";

export default function News2() {
  return (
    <div className="container py-5">
      <h1 className="mb-3 text-[#003366]">Dzień Otwarty Szkoły – zapraszamy!</h1>
      <p className="text-muted">18 listopada 2025</p>
      <img
        src="/src/assets/news2.jpg"
        alt="Dzień Otwarty"
        className="img-fluid rounded mb-4"
        style={{ maxHeight: "400px", objectFit: "cover", width: "100%" }}
      />
      <p>
        Już wkrótce odbędzie się Dzień Otwarty TM1. Zapraszamy uczniów klas 8 SP oraz ich rodziców!  
        Będzie można zobaczyć pracownie, porozmawiać z nauczycielami oraz wziąć udział w warsztatach pokazowych.
      </p>
      <p>
        To świetna okazja, aby poznać naszą szkołę i dowiedzieć się więcej o kierunkach nauczania i możliwościach rozwoju.
      </p>
    </div>
  );
}
