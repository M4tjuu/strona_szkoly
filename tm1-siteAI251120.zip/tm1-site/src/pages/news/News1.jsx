import React from "react";

export default function News1() {
  return (
    <div className="container py-5">
      <h1 className="mb-3 text-primary">Nowoczesne laboratorium mechatroniczne otwarte!</h1>
      <p className="text-muted">12 listopada 2025</p>
      <img
        src="/src/assets/news1.jpg"
        alt="Laboratorium Mechatroniczne"
        className="img-fluid rounded mb-4"
        style={{ maxHeight: "400px", objectFit: "cover", width: "100%" }}
      />
      <p>
        W naszym technikum otwarto nowe laboratorium mechatroniczne wyposażone w nowoczesne roboty przemysłowe, drukarki 3D oraz stanowiska automatyki. Uczniowie mają teraz możliwość praktycznego kształcenia w środowisku identycznym jak w przemyśle.
      </p>
      <p>
        Laboratorium będzie służyć zarówno do zajęć praktycznych, jak i projektów konkursowych oraz współpracy z lokalnymi firmami technologicznymi.
      </p>
    </div>
  );
}
