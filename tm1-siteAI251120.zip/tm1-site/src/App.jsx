import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";

import Home from "./pages/Home";
import About from "./pages/About";
import Offer from "./pages/Offer";
import Rekrutacja from "./pages/Rekrutacja";
import Kontakt from "./pages/Kontakt";
import Plan from "./pages/Plan";
import News1 from "./pages/news/News1";
import News2 from "./pages/news/News2";
import News3 from "./pages/news/News3";

export default function App() {
  return (
    <Router>
      <div className="d-flex flex-column min-vh-100"> {/* min-vh-100 = full viewport height */}
        <Navbar />
        <div className="grow"> {/* treść wypełnia resztę */}
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/offer" element={<Offer />} />
            <Route path="/rekrutacja" element={<Rekrutacja />} />
            <Route path="/kontakt" element={<Kontakt />} />
            <Route path="/plan" element={<Plan />} />
            <Route path="/news/1" element={<News1 />} />
            <Route path="/news/2" element={<News2 />} />
            <Route path="/news/3" element={<News3 />} />
          </Routes>
        </div>
        <Footer /> {/* zawsze na dole */}
      </div>
    </Router>
  );
}
