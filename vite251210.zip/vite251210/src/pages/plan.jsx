import React, { useEffect, useState } from "react";

export default function Plan() {
  const [selectedClass, setSelectedClass] = useState("1ta");
  const [plan, setPlan] = useState([]);
  const [loading, setLoading] = useState(false);

const godzinyLekcji = [
    "8:00 - 8:45",
    "8:50 - 9:35",
    "9:40 - 10:25",
    "10:30 - 11:15",
    "11:35 - 12:20",
    "12:40 - 13:25",
    "13:30 - 14:15",
    "14:20 - 15:05",
  ];

  // Pobieranie planu lekcji z backendu
  const fetchPlan = async (klasa) => {
    try {
      setLoading(true);
      const res = await fetch(`http://localhost:4000/api/plan/${klasa.toUpperCase()}`);
      const data = await res.json();

      if (data.plan) {
        const maxLessons = 8;
        const dni = ["Poniedzialek", "Wtorek", "Sroda", "Czwartek", "Piatek"];

        const tabela = Array.from({ length: maxLessons }, (_, i) => ({
          Nr: i + 1,
          godzina: godzinyLekcji[i], // wypełnienie godzinami
          pon: "",
          wt: "",
          sr: "",
          czw: "",
          pt: ""
        }));

        data.plan.forEach((dzien) => {
          const key = {
            "Poniedzialek": "pon",
            "Wtorek": "wt",
            "Sroda": "sr",
            "Czwartek": "czw",
            "Piatek": "pt"
          }[dzien.dzien_tygodnia];

          dzien.lekcje.forEach((lekcja) => {
            const nr = lekcja.godzina_lekcyjna - 1;
            if (tabela[nr])
              tabela[nr][key] = `${lekcja.przedmiot} ${lekcja.nauczyciel} ${lekcja.sala}`;
          });
        });

        setPlan(tabela);
      } else {
        setPlan([]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Jak sie wejdzie to 1ta pokazuje
  useEffect(() => {
    fetchPlan(selectedClass);
  }, []);

  // Zmiana klasy w select
  const handleChange = (e) => {
    const klasa = e.target.value;
    setSelectedClass(klasa);
    fetchPlan(klasa);
  };

  return (
    <main className="tw:bg-[#F7F7F7] tw:mx-[5%] tw:lg:mx-[10%] tw:my-8 tw:p-6 tw:rounded-2xl tw:shadow-md">
      <h1 className="tw:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:font-extrabold tw:leading-none tw:tracking-tight tw:text-center tw:mb-6">
        Wybierz klasę
      </h1>

      {/* SELECT */}
      <div className="tw:flex tw:justify-start tw:mb-8">
        <select
          className="form-select tw:w-48 tw:p-2 tw:rounded-md tw:border tw:border-gray-300 tw:font-semibold"
          value={selectedClass}
          onChange={handleChange}
        >
          <option value="1ta">1TA</option>
          <option value="2tc">2TC</option>
          <option value="5tb">5TB</option>
        </select>
      </div>

      {/* TABELA */}
      <div className="tw:overflow-x-auto">
        <table className="table table-striped tw:w-full tw:text-center align-middle">
          <thead className="tw:bg-gray-200">
            <tr>
              <th className="tw:sticky tw:left-0 tw:z-10">Nr</th>
              <th>Godzina</th>
              <th>Poniedziałek</th>
              <th>Wtorek</th>
              <th>Środa</th>
              <th>Czwartek</th>
              <th>Piątek</th>
            </tr>
          </thead>

          <tbody>
            {loading ? (
              <tr>
                <td colSpan="7" className="tw:p-4 tw:text-lg">
                  Ładowanie...
                </td>
              </tr>
            ) : plan.length === 0 ? (
              <tr>
                <td colSpan="7" className="tw:p-4 tw:text-red-500">
                  Brak danych dla tej klasy.
                </td>
              </tr>
            ) : (
              plan.map((lekcja) => (
                <tr key={lekcja.Nr} className="tw:border-b tw:border-gray-200">
                  <td className="tw:font-semibold tw:bg-gray-50 tw:sticky tw:left-0 tw:z-10">
                    {lekcja.Nr}
                  </td>
                  <td className="tw:font-medium">{lekcja.godzina}</td>
                  <td>{lekcja.pon}</td>
                  <td>{lekcja.wt}</td>
                  <td>{lekcja.sr}</td>
                  <td>{lekcja.czw}</td>
                  <td>{lekcja.pt}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <p className="tw:text-md tw:text-gray-600 tw:mt-2 tw:text-left">
        Plan obowiązuje od 16.09.2025.
      </p>
    </main>
  );
}
