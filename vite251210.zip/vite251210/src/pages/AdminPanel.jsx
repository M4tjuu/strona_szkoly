import React, { useEffect, useState } from "react";

export default function AdminPanel() {
  const [zastepstwa, setZastepstwa] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Pobieranie danych
  useEffect(() => {
    async function load() {
      setLoading(true);
      const res = await fetch("http://localhost:4000/api/zastepstwa");
      const data = await res.json();
      setZastepstwa(data);
      setLoading(false);
    }
    load();
  }, []);

  // Aktualizacja jednego pola
  function updateField(id, field, value) {
    setZastepstwa((prev) =>
      prev.map((item) =>
        item._id === id ? { ...item, [field]: value } : item
      )
    );
  }

  // Zapis na backend
  async function saveItem(item) {
    setSaving(true);
    try {
      const res = await fetch(
        `http://localhost:4000/api/zastepstwa/${item._id}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(item),
        }
      );

      if (!res.ok) {
        alert("Błąd podczas zapisywania!");
      } else {
        alert("Zapisano!");
      }
    } catch (err) {
      alert("Błąd połączenia z backendem");
    }
    setSaving(false);
  }

  if (loading) return <p>Ładowanie...</p>;

  return (
    <main className="tw:mx-[5%] tw:lg:mx-[15%] tw:my-10 tw:space-y-10">
      <h1 className="tw:text-4xl tw:font-bold tw:mb-6">Panel administracyjny</h1>

      {zastepstwa.map((item) => (
        <section
          key={item._id}
          className="tw:bg-white tw:p-6 tw:rounded-xl tw:shadow-md tw:space-y-4"
        >
          <h2 className="tw:text-xl tw:font-bold tw:mb-2">
            Edycja zastępstwa – ID: {item._id}
          </h2>

          <div className="tw:grid tw:grid-cols-1 tw:lg:grid-cols-2 tw:gap-4">
            {/* Data */}
            <div>
              <label className="tw-font-semibold">Data</label>
              <input
                type="date"
                className="tw:w-full tw:border tw:p-2 tw:rounded"
                value={item.data?.substring(0, 10)}
                onChange={(e) => updateField(item._id, "data", e.target.value)}
              />
            </div>

            {/* Klasa */}
            <div>
              <label className="tw-font-semibold">Klasa</label>
              <input
                className="tw:w-full tw:border tw:p-2 tw:rounded"
                value={item.klasa}
                onChange={(e) => updateField(item._id, "klasa", e.target.value)}
              />
            </div>

            {/* Godzina lekcyjna */}
            <div>
              <label className="tw-font-semibold">Godzina lekcyjna</label>
              <input
                type="number"
                className="tw:w-full tw:border tw:p-2 tw:rounded"
                value={item.godzina_lekcyjna}
                onChange={(e) =>
                  updateField(item._id, "godzina_lekcyjna", e.target.value)
                }
              />
            </div>

            {/* Nauczyciel stary */}
            <div>
              <label className="tw-font-semibold">Nauczyciel (nieobecny)</label>
              <input
                className="tw:w-full tw:border tw:p-2 tw:rounded"
                value={item.nauczyciel_stary}
                onChange={(e) =>
                  updateField(item._id, "nauczyciel_stary", e.target.value)
                }
              />
            </div>

            {/* Nauczyciel nowy */}
            <div>
              <label className="tw-font-semibold">Zastępca</label>
              <input
                className="tw:w-full tw:border tw:p-2 tw:rounded"
                value={item.nauczyciel_nowy}
                onChange={(e) =>
                  updateField(item._id, "nauczyciel_nowy", e.target.value)
                }
              />
            </div>

            {/* Uwagi */}
            <div className="tw:lg:col-span-2">
              <label className="tw-font-semibold">Uwagi</label>
              <textarea
                className="tw:w-full tw:border tw:p-2 tw:rounded tw:min-h-20"
                value={item.uwagi || ""}
                onChange={(e) =>
                  updateField(item._id, "uwagi", e.target.value)
                }
              ></textarea>
            </div>
          </div>

          {/* Przycisk zapisania */}
          <button
            onClick={() => saveItem(item)}
            disabled={saving}
            className="tw:bg-[#93041C] tw:text-white tw:px-4 tw:py-2 tw:rounded-md tw:font-bold tw:no-underline tw:inline-block tw:hover:opacity-100 tw:hover:scale-105 tw:transition-transform"
          >
            {saving ? "Zapisywanie..." : "Zapisz zmiany"}
          </button>
        </section>
      ))}
    </main>
  );
}
