import React, { useEffect, useState } from "react";

export default function Zastepstwa() {
  const [zastepstwa, setZastepstwa] = useState([]);
  const [nauczycieleMap, setNauczycieleMap] = useState({});
  const [data, setData] = useState("");

  useEffect(() => {
    async function loadData() {
      const nauczycieleRes = await fetch("http://localhost:4000/api/nauczyciele");
      const nauczyciele = await nauczycieleRes.json();

      const map = {};
      nauczyciele.forEach((n) => {
        map[n.inicjaly] = `${n.imie} ${n.nazwisko}`;
      });
      setNauczycieleMap(map);

      const zastepstwaRes = await fetch("http://localhost:4000/api/zastepstwa");
      const items = await zastepstwaRes.json();
      if (items.length === 0) return;

      const rawDate = items[0].data;
      const jsDate = new Date(rawDate);
      const formatted =
        jsDate.toLocaleDateString("pl-PL", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
        }) +
        " (" +
        jsDate.toLocaleDateString("pl-PL", { weekday: "long" }) +
        ")";

      setData(formatted);

      const grouped = {};
      items.forEach((item) => {
        const nauczycielInit = item.nauczyciel_stary;

        if (!grouped[nauczycielInit]) {
          grouped[nauczycielInit] = {
            nauczyciel: nauczycielInit,
            lekcje: [],
          };
        }

        grouped[nauczycielInit].lekcje.push({
          nr: item.godzina_lekcyjna,
          opis: `${item.klasa} — Zastępstwo`,
          zastepca: item.nauczyciel_nowy,
          uwagi: item.uwagi,
        });
      });

      setZastepstwa(Object.values(grouped));
    }

    loadData();
  }, []);

  function pelnaNazwa(inicjaly) {
    return nauczycieleMap[inicjaly] || inicjaly;
  }

  return (
    <main className="tw:bg-[#F7F7F7] tw:mx-[5%] tw:lg:mx-[10%] tw:my-8 tw:p-6 tw:rounded-2xl tw:shadow-md">
      <h1 className="tw:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:font-extrabold tw:leading-none tw:mb-6">
        Zastępstwa w dniu {data || "Ładowanie..."}
      </h1>

      <div className="tw:space-y-10">
        {zastepstwa.map((nauczyciel, i) => (
          <section key={i} className="tw:bg-white tw:rounded-xl tw:shadow-sm tw:p-4">
            <h2 className="tw:text-2xl tw:font-bold tw:text-dark tw:mb-4">
              {pelnaNazwa(nauczyciel.nauczyciel)}
            </h2>

            <div className="tw:overflow-x-auto">
              <table className="tw:w-full tw:text-center tw:border-collapse">
                <thead className="tw:bg-gray-200">
                  <tr>
                    <th className="tw:py-2 tw:px-3">Lekcja</th>
                    <th className="tw:py-2 tw:px-3">Opis</th>
                    <th className="tw:py-2 tw:px-3">Zastępca</th>

                    {/* UWAGI – NAJSZERSZA KOLUMNA */}
                    <th className="tw:py-2 tw:px-3 tw:min-w-[250px] tw:w-auto">
                      Uwagi
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {nauczyciel.lekcje.map((lekcja, idx) => (
                    <tr key={idx} className="tw:border-b tw:border-gray-200">
                      <td className="tw:py-2 tw:px-3 tw:font-semibold tw:bg-gray-50">
                        {lekcja.nr}
                      </td>
                      <td className="tw:py-2 tw:px-3">{lekcja.opis}</td>
                      <td className="tw:py-2 tw:px-3">
                        {pelnaNazwa(lekcja.zastepca) || "-"}
                      </td>

                      {/* DŁUGIE UWAGI — ZAWIJANIE */}
                      <td className="tw:py-2 tw:px-3 tw:min-w-[250px] tw:w-auto tw:whitespace-normal tw:wrap-break-word">
                        {lekcja.uwagi || "-"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        ))}
      </div>

      <p className="tw:text-md tw:text-gray-600 tw:mt-8 tw:text-left">
        Ostatnia aktualizacja: {data || "-"}
      </p>
    </main>
  );
}
