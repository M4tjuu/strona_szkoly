import React from "react";
import { Card, Button } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faComments, faChalkboard, faUsers } from "@fortawesome/free-solid-svg-icons";

export default function StrefaRodzica() {
  return (
    <main className="tw:bg-[#F7F7F7] tw:mx-[5%] tw:lg:mx-[10%] tw:my-8 tw:p-6 tw:rounded-2xl tw:shadow-md">
      <h1 className="tw:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:font-extrabold tw:text-center tw:mb-8">
        Strefa rodzica
      </h1>

      <p className="tw:text-center tw:text-gray-700 tw:text-lg tw:mb-10">
        Najważniejsze informacje dla rodziców - dostęp do dziennika, terminy zebrań i wiadomości ze szkoły.
      </p>

      <div className="row g-4">
        {/* --- KARTA 1: Dziennik elektroniczny --- */}
        <div className="col-12 col-md-4">
          <Card className="tw:h-full tw:shadow-sm tw:hover:shadow-lg tw:transition-shadow tw:duration-300 tw:rounded-xl tw:overflow-hidden">
            <div className="tw:h-48 tw:w-full tw:bg-gray-200 tw:flex tw:items-center tw:justify-center">
              <FontAwesomeIcon icon={faChalkboard} className="tw:text-[#93041C] tw:text-6xl" />
            </div>
            <Card.Body className="tw:text-center tw:p-5">
              <Card.Title className="tw:text-2xl tw:font-bold tw:mb-3 tw:text-gray-900">
                Dziennik elektroniczny
              </Card.Title>
              <Card.Text className="tw:text-gray-700 tw:mb-4">
                Sprawdź oceny, frekwencję i wiadomości wychowawcy w dzienniku elektronicznym.
              </Card.Text>
              <Button
                variant="danger"
                className="tw:rounded-full tw:px-4 tw:py-2 tw:text-white tw:font-semibold"
                href="https://uonetplus.vulcan.net.pl/warszawamokotow"
                target="_blank"
                rel="noopener noreferrer"
              >
                Przejdź do dziennika
              </Button>
            </Card.Body>
          </Card>
        </div>

        {/* --- KARTA 2: Wywiadówki --- */}
        <div className="col-12 col-md-4">
          <Card className="tw:h-full tw:shadow-sm tw:hover:shadow-lg tw:transition-shadow tw:duration-300 tw:rounded-xl tw:overflow-hidden">
            <div className="tw:h-48 tw:w-full tw:bg-gray-200 tw:flex tw:items-center tw:justify-center">
              <FontAwesomeIcon icon={faUsers} className="tw:text-gray-800 tw:text-6xl" />
            </div>
            <Card.Body className="tw:text-center tw:p-5">
              <Card.Title className="tw:text-2xl tw:font-bold tw:mb-3 tw:text-gray-900">
                Wywiadówki
              </Card.Title>
              <Card.Text className="tw:text-gray-700 tw:mb-4">
                Sprawdź terminy spotkań z wychowawcami i nauczycielami - bądź na bieżąco z życiem szkoły.
              </Card.Text>
              <Button download
                variant="secondary"
                className="tw:rounded-full tw:px-4 tw:py-2 tw:font-semibold"
                href="/dokumenty/kalendarz2025_2026.docx"
              >
                Zobacz terminy
              </Button>
            </Card.Body>
          </Card>
        </div>

        {/* --- KARTA 3: Wsparcie rodziców --- */}
        <div className="col-12 col-md-4">
          <Card className="tw:h-full tw:shadow-sm tw:hover:shadow-lg tw:transition-shadow tw:duration-300 tw:rounded-xl tw:overflow-hidden">
            <div className="tw:h-48 tw:w-full tw:bg-gray-200 tw:flex tw:items-center tw:justify-center">
              <FontAwesomeIcon icon={faComments} className="tw:text-[#1877F2] tw:text-6xl" />
            </div>
            <Card.Body className="tw:text-center tw:p-5">
              <Card.Title className="tw:text-2xl tw:font-bold tw:mb-3 tw:text-gray-900">
                Kontakt i komunikacja
              </Card.Title>
              <Card.Text className="tw:text-gray-700 tw:mb-4">
                Skontaktuj się z wychowawcą lub dyrekcją szkoły w razie pytań lub potrzeby pomocy.
              </Card.Text>
              <Button
                variant="primary"
                className="tw:rounded-full tw:px-4 tw:py-2 tw:font-semibold"
                href="/kontakt"
              >
                Przejdź do kontaktu
              </Button>
            </Card.Body>
          </Card>
        </div>
      </div>
    </main>
  );
}
