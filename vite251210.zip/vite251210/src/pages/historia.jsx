import React from "react";
import RedButton from "../components/RedButton";

export default function Historia() {
  return (
    <main className="tw:bg-[#F7F7F7] tw:mx-[5%] tw:lg:mx-[10%] tw:my-8 tw:px-4 tw:lg:px-8 tw:2xl:px-12 tw:rounded-2xl tw:shadow-md">
      <h1 className="tw:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:font-extrabold tw:leading-none tw:tracking-tight tw:text-center tw:mb-8 tw:pt-6">
        Historia szkoły
      </h1>

      <section className="tw:text-md tw:sm:text-lg tw:lg:text-xl tw:text-gray-800 tw:leading-relaxed tw:text-justify tw:space-y-4 tw:mb-6">
        <p>
          Historia szkoły przy ulicy <strong>Wiśniowej 56</strong> sięga lat
          <strong> 1900–1902</strong>, kiedy to zbudowano oficynę batalionową
          dla Koszar Keksholmskiego Pułku Piechoty Lejbgwardii. W okresie
          międzywojennym i w latach <strong>1948–1956</strong> w budynku mieścił
          się Korpus Kadetów. Później znajdowały się tam Szkoła
          Ogólnokształcąca nr 49 i Zasadnicza Szkoła Zawodowa nr 5, a od{" "}
          <strong>1963 r.</strong> działa tam Zespół Szkół Licealnych i
          Technicznych nr 1 (budynek główny).
        </p>
      </section>

      <section className="tw:bg-white tw:rounded-xl tw:shadow-sm tw:py-6 tw:mb-0">
        <h2 className="tw:text-2xl tw:font-semibold tw:text-gray-900 tw:mb-4 tw:pl-6">
          Etapy:
        </h2>

        <ul className="tw:text-gray-700">
          <li className="list-group-item tw:py-2">
            <strong>1900–1902:</strong> Budowa oficyny batalionowej dla Koszar
            Keksholmskiego Pułku Piechoty Lejbgwardii - początek istnienia
            budynku.
          </li>
          <li className="list-group-item tw:py-2">
            <strong>Okres międzywojenny i 1948–1956:</strong> W budynku mieściła
            się Szkoła Korpusu Kadetów.
          </li>
          <li className="list-group-item tw:py-2">
            <strong>Okres powojenny:</strong> W budynku znajdowała się Szkoła
            Ogólnokształcąca nr 49 oraz Zasadnicza Szkoła Zawodowa nr 5.
          </li>
          <li className="list-group-item tw:py-2">
            <strong>Od 1963 r.:</strong> W budynku działa Zespół Szkół
            Licealnych i Technicznych nr 1.
          </li>
        </ul>
      </section>

      <div className="tw:flex tw:float-right tw:my-8">
        <RedButton
          name="Więcej"
          link="https://warszawa.wyborcza.pl/warszawa/7,54420,25333257,carski-zabytek-miedzy-ministerstwem-spraw-wewnetrznych-a-agencja.html"
        />
      </div>
    </main>
  );
}
