import 'bootstrap/dist/css/bootstrap.min.css';
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import App from './App.jsx'
import Historia from './pages/historia.jsx';
import Kontakt from './pages/Kontakt.jsx';
import Plan from './pages/plan.jsx';
import Zastepstwa from './pages/zastepstwa.jsx';
import Dokumenty from './pages/dokumenty.jsx';
import StrefaUcznia from './pages/strefaucznia.jsx';
import StrefaRodzica from './pages/strefarodzica.jsx';
import StrefaKandydata from './pages/strefakandydata.jsx';
import Form from './pages/Form.jsx';
import Admin from './pages/AdminPanel.jsx';
import './index.css';

import Layout from './Layout.jsx';

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />, // layout otacza wszystkie podstrony
    children: [
      { path: "/", element: <App /> },
      { path: "/Historia", element: <Historia /> },
      { path: "/Kontakt", element: <Kontakt /> },
      { path: "/Plan", element: <Plan /> },
      { path: "/Zastepstwa", element: <Zastepstwa /> },
      { path: "/Dokumenty", element: <Dokumenty /> },
      { path: "/StrefaUcznia", element: <StrefaUcznia /> },
      { path: "/StrefaRodzica", element: <StrefaRodzica /> },
      { path: "/StrefaKandydata", element: <StrefaKandydata /> },
      { path: "/Form", element: <Form /> },
      { path: "/Admin", element: <Admin /> },
    ],
  },
]);

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)