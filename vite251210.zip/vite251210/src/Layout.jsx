import Navbar from './components/navbar.jsx'
import Footer from './components/footer.jsx';
import { Outlet } from 'react-router-dom';

export default function Layout() {
  return (
    <>
      <Navbar />
      <Outlet /> {/* zawartość strony */}
      <Footer />
    </>
  );
}