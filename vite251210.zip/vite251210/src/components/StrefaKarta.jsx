import React from "react";
import { NavLink } from 'react-router-dom';

export default function StrefaKarta({who, title, description, link}) {
    return (
        <div className="tw:w-full tw:lg:w-[30%] tw:min-w-[250px]">
          <NavLink to={link} className="tw:block tw:hover:scale-105 tw:transition-transform tw:mb-4 tw:sm:mb-5 tw:md:mb-6 tw:lg:mb-4">
            <img
              src={`/img/${who}cropped.png`}
              alt={who}
              className="tw:w-full tw:h-auto tw:rounded-lg"
            />
          </NavLink>
          <h2 className="tw:text-2xl tw:lg:text-3xl tw:text-gray-900 tw:font-extrabold tw:leading-none tw:tracking-tight tw:mb-1 tw:mt-3">
            {title}
          </h2>
          <p className="tw:text-xl tw:lg:text-2xl">
            {description}
          </p>
        </div>
  );
}
