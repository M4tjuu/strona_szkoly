import React, { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faRightToBracket } from "@fortawesome/free-solid-svg-icons";
import { faFacebook } from "@fortawesome/free-brands-svg-icons";
import { faYoutube } from "@fortawesome/free-brands-svg-icons";
import { faInstagram } from "@fortawesome/free-brands-svg-icons";

export default function NavBar() {
  const [open, setOpen] = useState(false);
  const toggleMenu = () => setOpen(!open);
  const location = useLocation();

  useEffect(() => {
    setOpen(false); // zamyka menu przy każdej zmianie strony
  }, [location]);

  return (
    <nav className="tw:bg-[#F7F7F7] tw:py-2.5 menuDrop">
      <div className="tw:flex tw:flex-wrap tw:items-center tw:justify-between tw:w-full tw:px-[5%] tw:lg:px-[10%] tw:relative">

        {/* Hamburger */}
        <button
          onClick={toggleMenu}
          className="tw:inline-flex tw:items-center tw:p-2 tw:text-sm tw:text-[#93041C] tw:rounded-lg tw:lg:hidden tw:hover:bg-gray-200 tw:active:bg-gray-300 tw:focus:outline-none"
        >
          <svg className="tw:w-6 tw:h-6" fill="currentColor" viewBox="0 0 20 20">
            <path
              fillRule="evenodd"
              d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4A1 1 0 013 5zM3 10a1 1 0 011-1h12a1 1 0 110 2H4A1 1 0 013 10zM3 15a1 1 0 011-1h12a1 1 0 110 2H4A1 1 0 013 15z"
              clipRule="evenodd"
            />
          </svg>
        </button>

        {/* Menu; li bez boostrapa tw:lg:py-2*/}
        <div
          className={`${
            open ? "tw:block" : "tw:hidden"
          } tw:absolute tw:top-full tw:left-0 tw:w-full tw:bg-[#F7F7F7] tw:shadow-md tw:lg:static tw:lg:block tw:lg:w-auto tw:lg:shadow-none tw:z-50`}
        >
          <ul className="tw:flex tw:flex-col tw:lg:flex-row tw:lg:space-x-6 tw:mt-2 tw:lg:mt-0 tw:border-t tw:lg:border-none tw:border-gray-300 tw:pl-[10%] tw:lg:pl-0">
            
            <li>
              <NavLink
                to="/"
                className={({ isActive }) =>
                  `tw:font-semibold tw:block tw:py-3 tw:px-1 tw:border-b tw:lg:border-0 tw:border-gray-200 tw:hover:bg-gray-100 tw:lg:hover:bg-transparent ${
                    isActive ? "tw:text-[#93041C] nav-active tw:bg-[#f1f1f1] tw:lg:bg-transparent" : "tw:text-black"
                  } tw:hover:text-[#93041C] tw:lg:py-0 tw:lg:pt-2 tw:transition-all tw:duration-200`
                }
              >
                Strona główna
              </NavLink>
            </li>

            <li>
              <a
                href="https://uonetplus.vulcan.net.pl/warszawamokotow"
                className="tw:font-semibold tw:block tw:py-3 tw:px-1 tw:border-b tw:lg:border-0 tw:border-gray-200 tw:hover:bg-gray-100 tw:lg:hover:bg-transparent tw:text-black tw:hover:text-[#93041C] tw:lg:py-0 tw:lg:pt-2 tw:transition-all tw:duration-200"
              >
                Dziennik
              </a>
            </li>

            <li>
              <NavLink
                to="/kontakt"
                className={({ isActive }) =>
                  `tw:font-semibold tw:block tw:py-3 tw:px-1 tw:border-b tw:lg:border-0 tw:border-gray-200 tw:hover:bg-gray-100 tw:lg:hover:bg-transparent ${
                    isActive ? "tw:text-[#93041C] nav-active tw:bg-[#f1f1f1] tw:lg:bg-transparent" : "tw:text-black"
                  } tw:hover:text-[#93041C] tw:lg:py-0 tw:lg:pt-2 tw:transition-all tw:duration-200`
                }
              >
                Kontakt
              </NavLink>
            </li>

            <li>
              <NavLink
                to="/plan"
                className={({ isActive }) =>
                  `tw:font-semibold tw:block tw:py-3 tw:px-1 tw:border-b tw:lg:border-0 tw:border-gray-200 tw:hover:bg-gray-100 tw:lg:hover:bg-transparent ${
                    isActive ? "tw:text-[#93041C] nav-active tw:bg-[#f1f1f1] tw:lg:bg-transparent" : "tw:text-black"
                  } tw:hover:text-[#93041C] tw:lg:py-0 tw:lg:pt-2 tw:transition-all tw:duration-200`
                }
              >
                Plan lekcji
              </NavLink>
            </li>

            <li>
              <NavLink
                to="/zastepstwa"
                className={({ isActive }) =>
                  `tw:font-semibold tw:block tw:py-3 tw:px-1 tw:border-b tw:lg:border-0 tw:border-gray-200 tw:hover:bg-gray-100 tw:lg:hover:bg-transparent ${
                    isActive ? "tw:text-[#93041C] nav-active tw:bg-[#f1f1f1] tw:lg:bg-transparent" : "tw:text-black"
                  } tw:hover:text-[#93041C] tw:lg:py-0 tw:lg:pt-2 tw:transition-all tw:duration-200`
                }
              >
                Zastępstwa
              </NavLink>
            </li>

            <li>
              <NavLink
                to="/dokumenty"
                className={({ isActive }) =>
                  `tw:font-semibold tw:block tw:py-3 tw:px-1 tw:border-b tw:lg:border-0 tw:border-gray-200 tw:hover:bg-gray-100 tw:lg:hover:bg-transparent ${
                    isActive ? "tw:text-[#93041C] nav-active tw:bg-[#f1f1f1] tw:lg:bg-transparent" : "tw:text-black"
                  } tw:hover:text-[#93041C] tw:lg:py-0 tw:lg:pt-2 tw:transition-all tw:duration-200`
                }
              >
                Dokumenty
              </NavLink>
            </li>
          </ul>
        </div>

        {/* Ikony */}
        <div className="tw:flex tw:items-center">
          <a href="/" className="tw:text-[#93041C] tw:ml-4 tw:text-xl tw:hover:opacity-60 tw:hover:scale-120 tw:transition-transform">
            <FontAwesomeIcon icon={faRightToBracket} />
            {/*<i className="fa-solid fa-right-to-bracket"></i>*/} {/* przed font awesome w react */}
          </a>
          <a
            target="_blank"
            rel="noreferrer"
            href="https://www.facebook.com/Technikum.Mechatroniczne.nr.1"
            className="tw:text-[#93041C] tw:ml-4 tw:text-xl tw:hover:opacity-60 tw:hover:scale-120 tw:transition-transform"
          >
            <FontAwesomeIcon icon={faFacebook} />
            {/*<i className="fa-brands fa-facebook"></i>*/}
          </a>
          <a
            target="_blank"
            rel="noreferrer"
            href="https://www.youtube.com/@wisniowa56official17"
            className="tw:text-[#93041C] tw:ml-4 tw:text-xl tw:hover:opacity-60 tw:hover:scale-120 tw:transition-transform"
          >
            <FontAwesomeIcon icon={faYoutube} />
          </a>
          <a
            target="_blank"
            rel="noreferrer"
            href="https://www.instagram.com/wisniowa56/"
            className="tw:text-[#93041C] tw:ml-4 tw:text-xl tw:hover:opacity-60 tw:hover:scale-120 tw:transition-transform"
          >
            <FontAwesomeIcon icon={faInstagram} />
          </a>
        </div>
      </div>
    </nav>
  );
}