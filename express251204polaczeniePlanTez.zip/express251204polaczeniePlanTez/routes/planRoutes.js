const express = require("express");
const router = express.Router();
const planController = require("../controllers/planController");

// GET /api/plan/2TC
router.get("/:klasa", planController.getPlanByClass);

module.exports = router;
