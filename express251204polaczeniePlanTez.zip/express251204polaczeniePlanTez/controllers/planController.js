const PlanLekcji = require("../models/PlanLekcji");

exports.getPlanByClass = async (req, res) => {
    try {
        const klasa = req.params.klasa.toUpperCase();

        console.log("SZUKANA KLASA:", klasa);

        const wszystkie = await PlanLekcji.find({});
        console.log("KLASY W BAZIE:", wszystkie.map(x => x.klasa));

        const plan = await PlanLekcji.findOne({ klasa: klasa });

        if (!plan) {
            return res.status(404).json({ error: "Nie znaleziono planu dla tej klasy" });
        }

        res.json(plan);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Błąd serwera" });
    }
};