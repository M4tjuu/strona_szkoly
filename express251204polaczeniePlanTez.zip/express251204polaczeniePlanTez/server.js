const express = require("express");
const cors = require("cors");
require("dotenv").config();
require("./database");

const nauczycielController = require("./controllers/nauczycielController");

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api", nauczycielController);

// tu plan
const planRoutes = require("./routes/planRoutes");

app.use("/api/plan", planRoutes);
// do tego miejsca

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is listening on ${PORT}`);
});
