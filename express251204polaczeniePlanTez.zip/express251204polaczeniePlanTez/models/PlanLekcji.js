const mongoose = require("mongoose");

// pojedyncza lekcja
const LekcjaSchema = new mongoose.Schema({
    godzina_lekcyjna: { type: Number, required: true },
    przedmiot: { type: String, required: true },
    nauczyciel: { type: String, required: true },
    sala: { type: String, required: true }
});

// dzień tygodnia z lekcjami
const DzienSchema = new mongoose.Schema({
    dzien_tygodnia: { type: String, required: true },
    lekcje: [LekcjaSchema]
});

// plan dla całej klasy
const PlanLekcjiSchema = new mongoose.Schema({
    klasa: { type: String, required: true, unique: true },
    plan: [DzienSchema]
}, {
    collection: "plan_lekcji" // kolekcja
});

// eksport modelu
module.exports = mongoose.model("PlanLekcji", PlanLekcjiSchema);
