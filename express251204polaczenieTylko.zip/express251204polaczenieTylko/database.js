require("dotenv").config();
const mongoose = require('mongoose');
mongoose.set('strictQuery', false);
const mongoDB_URI = process.env.MONGO_URL;

main().catch((err) => console.log(err));
//wyswietli dostępne kolekcje w bazie
async function main() {
    await mongoose.connect(mongoDB_URI);
    mongoose.connection.db
        .listCollections()
        .toArray()
        .then((coll) => console.log(coll));
}
