import { response } from "express";
import { useState } from "react";

export default function Form() {
    const [inputs, setInputs] = useState({
        imie: "",
        nazwisko: "",
        wiek: 0
    });

    // to sie znak po znaku uruchamia
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({...values, [name]: value}))
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        alert(JSON.stringify(inputs));
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(inputs)
        };
        fetch('https://localhost:3000/add', requestOptions)
        .then(response => response.json())
        .then(data => console.log(data.message));
    }

    return (
        <form onsubmit={handleSubmit}>
            <label>Podaj imie:
                <input 
                    type="text"
                    name="imie"
                    value={inputs.imie}
                    onChange={handleChange}
                />
            </label>
            <label>Podaj nazwisko:
                <input 
                    type="text"
                    name="nazwisko"
                    value={inputs.nazwisko}
                    onChange={handleChange}
                />
            </label>
            <label>Podaj wiek:
                <input 
                    type="number"
                    name="wiek"
                    value={inputs.wiek}
                    onChange={handleChange}
                />
            </label>
            <input type="submit" />
        </form>
    )
}