import React from "react";

export default function Footer() {
return ( <footer className="tw:px-[5%] tw:lg:px-[10%] tw:py-6 tw:bg-[#F7F7F7] tw:flex tw:flex-col tw:md:flex-row tw:justify-between tw:items-start tw:gap-8"> <div> <h3 className="tw:text-lg tw:mb-4">
Technikum Mechatroniczne nr 1 <br />
im. Piotra Drzewieckiego </h3> <div className="tw:flex"> <a
         target="_blank" rel="noreferrer"
         href="https://www.facebook.com/Technikum.Mechatroniczne.nr.1"
         className="tw:text-[#93041C] tw:mr-4 tw:text-xl tw:hover:opacity-60 tw:transition"
       > <i className="fa-brands fa-facebook"></i> </a> <a
         target="_blank" rel="noreferrer"
         href="https://www.youtube.com/@wisniowa56official17"
         className="tw:text-[#93041C] tw:mr-4 tw:text-xl tw:hover:opacity-60 tw:transition"
       > <i className="fa-brands fa-youtube"></i> </a> <a
         target="_blank" rel="noreferrer"
         href="https://www.instagram.com/wisniowa56/"
         className="tw:text-[#93041C] tw:mr-4 tw:text-xl tw:hover:opacity-60 tw:transition"
       > <i className="fa-brands fa-instagram"></i> </a> </div> </div>

{/* bez boostrapra; te "br'y" co sie robia jak sie boostrapa polaczy to margin-bottom i mozna go na 0 ustawic i wtedy jest ok tak jak w tym p kontakt zrobilem
  <div className="tw:max-w-[300px]">
    <p className="tw:font-bold">Kontakt</p>
    <p>szkola@tm1.edu.pl, sekretariat@tm1.edu.pl</p>
    <p>fax. 22 646-45-00</p>
    <p>ul. Wiśniowa 56, 02-520 Warszawa</p>
    <p>tel. 22 646-44-99 lub 22 646-44-98</p>
  </div>*/}
  <div className="tw:max-w-[300px]">
    <p className="tw:font-bold tw:mb-0">Kontakt</p>
    <p>szkola@tm1.edu.pl, sekretariat@tm1.edu.pl
    <br />fax. 22 646-45-00
    <br />ul. Wiśniowa 56, 02-520 Warszawa
    <br />tel. 22 646-44-99 lub 22 646-44-98</p>
  </div>
</footer>
);
}
