import React from "react";
            
export default function redButton({firma}) {
    /*const firmaUp = {firma}.toUppercase()*/
    return (
    <img
        src={`img/${firma}.png`}
        alt={firma}
        className="tw:max-h-300 tw:mix-blend-multiply tw:brightness-110"
    />
    );
}
            