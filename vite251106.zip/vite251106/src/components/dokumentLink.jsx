import React from "react";

export default function dokumentLink({ name, file }) {
  return (
    <li>
      <a
        href={`dokumenty/${file}`}
        download
        className="text-dark text-decoration-underline"
      >
        {name}
      </a>
    </li>
  );
}
