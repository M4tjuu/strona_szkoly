import React from "react";

export default function dokumentLink({title, content}) {
  return (
    <div className="tw:p-2">
        <h3 className="tw:text-xl tw:sm:text-3xl tw:lg:text-4xl tw:text-gray-900 tw:mb-2 tw:font-bold tw:leading-none tw:tracking-tight">
            {title}
        </h3>
        <p className="tw:text-lg tw:sm:text-2xl tw:lg:text-3xl tw:leading-medium">
            {content}
        </p>
    </div>
  );
}
