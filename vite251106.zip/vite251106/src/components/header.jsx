import React from "react";

export default function Header() {
    return (
        <header className="tw:px-[5%] tw:lg:px-[10%] tw:flex tw:justify-center tw:items-center tw:py-6 tw:bg-white tw:text-center">
            <img src="img/logo.png" alt="Logo szkoły" className="tw:w-40 tw:lg:mr-6" />
                <h1 className="tw:text-2xl tw:md:text-3xl tw:lg:text-4xl tw:xl:text-5xl tw:text-gray-900 tw:mb-6 tw:font-extrabold tw:leading-none tw:tracking-tight">Technikum Mechatroniczne nr 1<br />im. Piotra Drzewieckiego</h1>
        </header>
    );
}
