import 'bootstrap/dist/css/bootstrap.min.css';
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import App from './App.jsx'
import Kontakt from './pages/Kontakt.jsx';
import Plan from './pages/plan.jsx';
import Zastepstwa from './pages/zastepstwa.jsx';
import Dokumenty from './pages/dokumenty.jsx';
import './index.css';

import Layout from './Layout.jsx';

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />, // layout otacza wszystkie podstrony
    children: [
      { path: "/", element: <App /> },
      { path: "/Kontakt", element: <Kontakt /> },
      { path: "/Plan", element: <Plan /> },
      { path: "/Zastepstwa", element: <Zastepstwa /> },
      { path: "/Dokumenty", element: <Dokumenty /> },
      { path: "/Form", element: <Form /> },
    ],
  },
]);

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)